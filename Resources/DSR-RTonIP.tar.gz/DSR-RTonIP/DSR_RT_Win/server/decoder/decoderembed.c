//decoderembed.c (Decoder embed based on ETSI ES-201-108) (Part of DSR-RT. Granada Universty)

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#include "golay.h"
#include "q8.tab"
#include "../../common.h"  //For size of rtpPacket
#include "../statistic/statistic.h" //For struct info_pair_frame
#include "decoderembed.h"  //For HTK_DataFrame 

HTK_DataFrame SD, DETECTION_THRESHOLD;
dframe PreviousDFrame, 
       CurrentDFrame, 
       LastGoodDFrame, 
       *BufferedDFrames;
int dataframes; /*Global only for ease of printf statements showing warnings*/
int result,    
    dataframes_buffered,
    endFrames,
    buffering_data_mode;
unsigned char *globalOutputBuffer;
int globalOutputBufferSize;
extern info_framePairs ExtInfoFramePair[SIZEFRAMEPAIRS];  //see statistic definition
int sequence_number;



/* decoder_initialize */
void decoder_initialize()
{ 
    init_thresholds();

	dataframes=0;
	result = 1;	
	buffering_data_mode=TRUE;
	dataframes_buffered = 0;
	
	globalOutputBuffer = NULL;
	globalOutputBufferSize = 0;

	return;
}

/*decoder_finalize*/ 
void decoder_finalize() 
{
	return;
}


/***************************************
*	MAIN FUNCTION OF THIS MODULE
*
* 	int decode_two_frames( rtpPacket *inputbuffer, unsigned char **outputbuffer)
* 	decode two HTK_DataFrames from 12 chars in the inputbuffer
* 	and put the resulting frames into the outputbuffer parameters:
*	 rtpPacket *inputbuffer:  make sure, that it is possible to read 12 chars from this struct
* 	unsigned char *outputbuffer: will be changed to the current outputbuffer, content is 
*         only valid until the next call to decode_two_frames().
* 	returns the number of HTK_DataFrames written into the buffer
* 	or -1 on error; 
******************************************************/
int decode_two_frames(rtpPacket *inputbuffer, unsigned char **outputbuffer) 
{

	free(globalOutputBuffer);
	globalOutputBuffer = NULL;
	globalOutputBufferSize = -1;    
	
	//MAIN ERROR MITIGATION
	
    sequence_number = inputbuffer->sequence_number;	//for statistc-fich
	//Separte the two frame an see CRC		
	endFrames = convert_pair(inputbuffer->payload, &CurrentDFrame); 	   
    dataframes += 2;
	//Error Mitigation and Decode	
    buffering_data_mode = process_two_frames(&BufferedDFrames, &CurrentDFrame, &LastGoodDFrame, &PreviousDFrame,
                                                                &dataframes_buffered, endFrames, buffering_data_mode);
      
  	*outputbuffer = globalOutputBuffer;
	return globalOutputBufferSize;
}

/**********************************************************************
*Separate the bits of two_data_frames in DataFrame.a and DataFrame.b. This function return:
*if no_crc_error Return 0 if unsigned char a[7]={0, 0, 0, 0, 0, 0, 0} (7zeros)
*if no_crc_error Return 1 if a < 7 zeros and b == 7 zeros
*if no_crc_error Return 2 if a < 7zeros and b < 7 zeros 
*if crc_error Return 4 if a > ZEROS_THRESHOLD (5)
*if crc_error Return 5 if a < Z_T and b > Z_T
*if crc_error Return 6 if a < Z_T and b > Z_T
*********************************************/
int convert_pair(unsigned char *two_data_frames, dframe *DataFrame)
{
	int index, frames_non_zero=2, zeros_found;

  DataFrame->a[0] = (0x3f & two_data_frames[0]);
  DataFrame->a[1] = (0x03 & (two_data_frames[0]>>6));
  DataFrame->a[1] |= (0x3c & (two_data_frames[1]<<2));
  DataFrame->a[2] = (0x0f & (two_data_frames[1]>>4));
  DataFrame->a[2] |= (0x30 & (two_data_frames[2]<<4));
  DataFrame->a[3] = (0x3f & (two_data_frames[2]>>2));
  DataFrame->a[4] = (0x3f & two_data_frames[3]);
  DataFrame->a[5] = (0x03 & (two_data_frames[3]>>6));
  DataFrame->a[5] |= (0x3c & (two_data_frames[4]<<2));
  DataFrame->a[6] = (0x0f & (two_data_frames[4]>>4));
  DataFrame->a[6] |= (0xf0 & (two_data_frames[5]<<4));

  DataFrame->b[0] = (0x0f & (two_data_frames[5])>>4);
  DataFrame->b[0] |= (0x30 & (two_data_frames[6])<<4);
  DataFrame->b[1] = (0x3f & (two_data_frames[6]>>2));
  DataFrame->b[2] = (0x3f & two_data_frames[7]);
  DataFrame->b[3] = (0x03 & (two_data_frames[7]>>6));
  DataFrame->b[3] |= (0x3c & (two_data_frames[8]<<2));
  DataFrame->b[4] = (0x0f & (two_data_frames[8]>>4));
  DataFrame->b[4] |= (0x30 & (two_data_frames[9]<<4));
  DataFrame->b[5] = (0x3f & (two_data_frames[9]>>2));
  DataFrame->b[6] = (0xff & two_data_frames[10]);

  DataFrame->crc = (0x0f & two_data_frames[11]);

	//SEE CRC AND N� OF ZEROS
  if(crc_errors(two_data_frames, DataFrame->crc)==TRUE)
  {
    fprintf(stderr,"\nDECODER: A CRC (%d) error detected in sequence_number: %d", DataFrame->crc, sequence_number);    
	ExtInfoFramePair[sequence_number].CRC_error=1;
	
	zeros_found = 0;
    for(index=0; index<7; index++)
      if(DataFrame->a[index]==0) zeros_found++;
    if(zeros_found>=ZEROS_THRESHOLD)
      frames_non_zero=0;  /*i.e. these are all zero padding frames*/
    else
    {
      zeros_found = 0;
      for(index=0; index<7; index++)
        if(DataFrame->b[index]==0) zeros_found++;
      if(zeros_found>=ZEROS_THRESHOLD)
        frames_non_zero=1;
      else
        frames_non_zero=2;
    }
    frames_non_zero |= 0x4;
  }
  else
  {
    zeros_found = 0;
    for(index=0; index<7; index++)
      if(DataFrame->a[index]==0) zeros_found++;
    if(zeros_found==7)  /*CRC is ok therefore all indicies have to be zero for padding*/
      frames_non_zero=0;
    else
    {
      zeros_found = 0;
      for(index=0; index<7; index++)
        if(DataFrame->b[index]==0) zeros_found++;
      if(zeros_found==7)
        frames_non_zero=1;
      else
        frames_non_zero=2;
    }
  }
  return frames_non_zero;
}

/* Write in   globalOutputBuffer the 14 coeff*/
void write_htk_coefs(HTK_DataFrame *given)
{
  if (globalOutputBufferSize < 0)
		globalOutputBufferSize = 0;
  globalOutputBuffer = (unsigned char *) realloc(globalOutputBuffer, sizeof(HTK_DataFrame) * (globalOutputBufferSize + 1));
  memcpy(&(globalOutputBuffer[sizeof(HTK_DataFrame) * globalOutputBufferSize]), given, sizeof(HTK_DataFrame));
  globalOutputBufferSize++; 
  
  return;
}



/* Dequantise dframe and using write_htk_coefs writes in globalOutputBuffer the 14 coef*/
void write_two_data_frames(dframe given, int numFrames)
{
  HTK_DataFrame quantised_frame;
  
  dequantise_dataframe(&quantised_frame, given.a);
  write_htk_coefs(&quantised_frame);  
  
  if(numFrames==TWO_FRAMES)
  {
    dequantise_dataframe(&quantised_frame, given.b);
    write_htk_coefs(&quantised_frame);			
  }
  
  
  return;
}

void init_thresholds(void)
{
  SD.c1 =    2.33137;
  SD.c2 =    1.88561;
  SD.c3 =    1.64834;
  SD.c4 =    1.56232;
  SD.c5 =    1.46181;
  SD.c6 =    1.38316;
  SD.c7 =    1.31014;
  SD.c8 =    1.22508;
  SD.c9 =    1.17092;
  SD.c10 =   1.10437;
  SD.c11 =   1.05289;
  SD.c12 =   0.96728;
  SD.c0 =    5.42705;
  SD.logE =  0.53702;

  DETECTION_THRESHOLD.c1   = DETECTION_THRES_COEF * SD.c1;
  DETECTION_THRESHOLD.c2   = DETECTION_THRES_COEF * SD.c2;
  DETECTION_THRESHOLD.c3   = DETECTION_THRES_COEF * SD.c3;
  DETECTION_THRESHOLD.c4   = DETECTION_THRES_COEF * SD.c4;
  DETECTION_THRESHOLD.c5   = DETECTION_THRES_COEF * SD.c5;
  DETECTION_THRESHOLD.c6   = DETECTION_THRES_COEF * SD.c6;
  DETECTION_THRESHOLD.c7   = DETECTION_THRES_COEF * SD.c7;
  DETECTION_THRESHOLD.c8   = DETECTION_THRES_COEF * SD.c8;
  DETECTION_THRESHOLD.c9   = DETECTION_THRES_COEF * SD.c9;
  DETECTION_THRESHOLD.c10  = DETECTION_THRES_COEF * SD.c10;
  DETECTION_THRESHOLD.c11  = DETECTION_THRES_COEF * SD.c11;
  DETECTION_THRESHOLD.c12  = DETECTION_THRES_COEF * SD.c12;
  DETECTION_THRESHOLD.c0   = DETECTION_THRES_COEF * SD.c0;
  DETECTION_THRESHOLD.logE = DETECTION_THRES_COEF * SD.logE;

  return;
}

int process_two_frames(dframe **BufferedDFrames, dframe *CurrentDFrame, dframe *LastGoodDFrame, dframe *PreviousDFrame,
                        int *dataframes_buffered, int endFrames, int buffering_data_mode)
{
  
  if(buffering_data_mode)
  {
    if(endFrames & 0x4) //crc is in error
    {
      (*dataframes_buffered) += 2;
      add_to_buffer(BufferedDFrames, CurrentDFrame, (*dataframes_buffered));
    }
    else
    {
      if(threshold_error(*CurrentDFrame))
      {
        (*dataframes_buffered) += 2;
        add_to_buffer(BufferedDFrames, CurrentDFrame, (*dataframes_buffered));
      }
      else
      {

        if((*dataframes_buffered)>0)
        {
          error_correct_and_write(LastGoodDFrame->b, CurrentDFrame->a, *BufferedDFrames, *dataframes_buffered);
          //i.e. frame repeat backwards
          free(*BufferedDFrames); (*BufferedDFrames) = NULL;
          (*dataframes_buffered) = 0;
        }
        memcpy(PreviousDFrame, CurrentDFrame, sizeof(struct dframe));
        memcpy(LastGoodDFrame, CurrentDFrame, sizeof(struct dframe));

        buffering_data_mode = FALSE;
      }
    }
  }
  else //Not buffering data mode
  {
    if(endFrames & 0x4) //crc is in error
    {
      dataframes -= 4;

      if(threshold_error(*PreviousDFrame))
      {
        dataframes += 4;

        (*dataframes_buffered) += 2;
        add_to_buffer(BufferedDFrames, PreviousDFrame, (*dataframes_buffered));

        (*dataframes_buffered) += 2;
        add_to_buffer(BufferedDFrames, CurrentDFrame, (*dataframes_buffered));

        buffering_data_mode = TRUE;
      }
      else //threshold of previous is ok
      {
        dataframes += 4;

        write_two_data_frames(*PreviousDFrame, TWO_FRAMES);
        memcpy(LastGoodDFrame, PreviousDFrame, sizeof(struct dframe));

        (*dataframes_buffered) += 2;
        add_to_buffer(BufferedDFrames, CurrentDFrame, (*dataframes_buffered));

        buffering_data_mode = TRUE;
      }
    }
    else //crc was ok
    {
      write_two_data_frames(*PreviousDFrame, TWO_FRAMES);
      memcpy(LastGoodDFrame, PreviousDFrame, sizeof(struct dframe));

      memcpy(PreviousDFrame, CurrentDFrame, sizeof(struct dframe));
    }
  }

	

	return buffering_data_mode;

}


void add_to_buffer(dframe **BufferedData, dframe *ToBuffer, int buffered_count)
{

  /*buffered_count+1 since may have half a frame at the end. and will want to alloc space for that too.*/

  (*BufferedData) = (struct dframe *) realloc((struct dframe *)(*BufferedData), sizeof(struct dframe) * ((buffered_count+1)/2));

  if((*BufferedData)==NULL)
  {
    fprintf(stderr,"\nError: Out of memory allocating space for Data !");
    exit(1);
  }

  memcpy(&((*BufferedData)[((buffered_count+1)/2) - 1]), ToBuffer, sizeof(struct dframe));


  return;

}

int threshold_error(dframe DataFrame)
{
  HTK_DataFrame difference, first, second;
  int threshold_errors = 0, result = 0;

  dequantise_dataframe(&first, DataFrame.a);
  dequantise_dataframe(&second, DataFrame.b);


  difference.c1   = fabs(second.c1   - first.c1);
  difference.c2   = fabs(second.c2   - first.c2);
  difference.c3   = fabs(second.c3   - first.c3);
  difference.c4   = fabs(second.c4   - first.c4);
  difference.c5   = fabs(second.c5   - first.c5);
  difference.c6   = fabs(second.c6   - first.c6);
  difference.c7   = fabs(second.c7   - first.c7);
  difference.c8   = fabs(second.c8   - first.c8);
  difference.c9   = fabs(second.c9   - first.c9);
  difference.c10  = fabs(second.c10  - first.c10);
  difference.c11  = fabs(second.c11  - first.c11);
  difference.c12  = fabs(second.c12  - first.c12);
  difference.c0   = fabs(second.c0   - first.c0);
  difference.logE = fabs(second.logE - first.logE);



  threshold_errors = 0;

  if((difference.c1 > DETECTION_THRESHOLD.c1)   || (difference.c2 > DETECTION_THRESHOLD.c2))     threshold_errors++;
  if((difference.c3 > DETECTION_THRESHOLD.c3)   || (difference.c4 > DETECTION_THRESHOLD.c4))     threshold_errors++;
  if((difference.c5 > DETECTION_THRESHOLD.c5)   || (difference.c6 > DETECTION_THRESHOLD.c6))     threshold_errors++;
  if((difference.c7 > DETECTION_THRESHOLD.c7)   || (difference.c8 > DETECTION_THRESHOLD.c8))     threshold_errors++;
  if((difference.c9 > DETECTION_THRESHOLD.c9)   || (difference.c10 > DETECTION_THRESHOLD.c10))   threshold_errors++;
  if((difference.c11 > DETECTION_THRESHOLD.c11) || (difference.c12 > DETECTION_THRESHOLD.c12))   threshold_errors++;
  if((difference.c0 > DETECTION_THRESHOLD.c0)   || (difference.logE > DETECTION_THRESHOLD.logE)) threshold_errors++;

  if(threshold_errors >= ERRORS_THRESHOLD)
  {

    fprintf(stderr,"\nDECODER: Threshold error %2d near of sequence_number %d", 
						threshold_errors, sequence_number);

    result = -1;

  }


  return result;
}

void dequantise_dataframe(HTK_DataFrame *result, unsigned char *given_index)
{
  result->c1   = quantiser8kHz_0_1[given_index[0]][0];
  result->c2   = quantiser8kHz_0_1[given_index[0]][1];
  result->c3   = quantiser8kHz_2_3[given_index[1]][0];
  result->c4   = quantiser8kHz_2_3[given_index[1]][1];
  result->c5   = quantiser8kHz_4_5[given_index[2]][0];
  result->c6   = quantiser8kHz_4_5[given_index[2]][1];
  result->c7   = quantiser8kHz_6_7[given_index[3]][0];
  result->c8   = quantiser8kHz_6_7[given_index[3]][1];
  result->c9   = quantiser8kHz_8_9[given_index[4]][0];
  result->c10  = quantiser8kHz_8_9[given_index[4]][1];
  result->c11  = quantiser8kHz_10_11[given_index[5]][0];
  result->c12  = quantiser8kHz_10_11[given_index[5]][1];
  result->c0   = quantiser8kHz_12_13[given_index[6]][0];
  result->logE = quantiser8kHz_12_13[given_index[6]][1];
  return;
}

void error_correct_and_write(unsigned char Left[7], unsigned char Right[7], dframe *BufferedData, int count)
{
  int i;
  HTK_DataFrame L, R;


  if((Left==NULL) && (Right==NULL)) /*No good left or right data given, thus have to just put out bad data.*/
  {
    fprintf(stderr,"\nWriting out bad data !");
  
    for(i=0; i<count; i+=2)
      write_two_data_frames(BufferedData[i/2], TWO_FRAMES);

    if((i%2)!=0) /*in case of odd one at the end.*/
    {
      write_two_data_frames(BufferedData[(count+1)/2], ONE_FRAME);
    }
  }
  else
  {

     /*Dequantise the given good indicies*/
     dequantise_dataframe(&L, Left);
     dequantise_dataframe(&R, Right);

    fprintf(stderr,"\nDECODER: Writing left frame to correct, near of sequence_number %d", sequence_number);
	for(i=1; i<=((count+1)/2); i++)
    {  	   
	   write_htk_coefs(&L);
	}

	fprintf(stderr,"\nDECODER: Writing right frame to correct, near of sequence_number %d", sequence_number);
    for(i=(((count+1)/2)+1); i<=count; i++)
	{
       write_htk_coefs(&R);
	}
	 
  }



  return;
}



