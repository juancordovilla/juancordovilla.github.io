/*******************************************************
*	AUTOR: 		Juan Andr�s Morales Cordovilla (&Timo Bauman) 
*				For the Granada University. July 2006
*	NAME:		fatherTCP.c (Father TCP)
*	DESCRIPTION: 	Code of the proyect DSR-RT. 
*				It�s the first code that is executed by the Server
*				Program (fatherTCP).
**********************************************************/


#include <stdio.h>
#include <stdlib.h> //For exit()
#include <string.h> //For strcpy
#include <unistd.h>  // usleep()
#include <signal.h> //To kill()
#include <sys/wait.h> //For wait()
#include <fcntl.h> //For fcntl, non blocking tube
#include "serverTCP/serverembedTCP.h" 
#include "../common.h"  //for  SIGSERVER

void childUDP(int *tube);

int main ()
{
	int pidchild, tube[2], proof_num=-1;
	
		
  while(1)
  {
	proof_num++;
	fprintf(stderr,"\n\n\n-------------------------- PROOF %d --------------------------", proof_num%3);	
	
	//Initializace a TCP connections
	InitiaServerTCP ();		
  
	//Create child UDP    
	pipe(tube);	//Open  where father and children write and read common dates in non-block mode
	fcntl(tube[0], F_SETFL, O_NONBLOCK);	
	if ((pidchild=fork())==0)
	{
		childUDP(tube);  //CHILD, Tube to read and write
		fprintf(stderr,"\nTERMINATED CHILDREN \n");
		exit(0);
	}	
	
	/*********************************************
	*	MAIN FUNCTION OF THIS MODULE (father)
	*	wait to receive TCPF and finalize all Server program
	*********************************************/
	else
	{	
		char cad[CADSIZETCP]; 
		int status;
				
		//Father wait to recive TCPF in blocking mode	
		ReceiveTCP(cad);         	
		
		//Say to child UDP stop
		strcpy(cad,"UDPF");
		write(tube[1], cad, sizeof(cad));		
		kill(pidchild, SIGSERVER);
		
		while(wait(&status) != pidchild); //Father Waits to Finalize Child to avoid zombies
				
		close(tube[0]); close(tube[1]);	//Close tube connector
		
		//Send and rename FichStat
		fprintf(stderr,"\n... Sending TCPSpeechFile ..");
		SendTCPSpeechFile();
		
		if(proof_num%3==0)
			rename("FichStat.txt", "FichStat0.txt");
		if(proof_num%3==1)
			rename("FichStat.txt", "FichStat1.txt");	
		if(proof_num%3==2)
			rename("FichStat.txt", "FichStat2.txt");
		
			
		//Close TCP connections			
		FinalizeTCP();
		fprintf(stderr,"\nTERMINATED FATHER\n");		
	}	
  }
  
	
	return 1;
}




	


