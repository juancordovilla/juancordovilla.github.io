//serverembedTCP.c (Server embed TCP)  (Part of DSR-RT. Granada Universty)

#include <stdio.h>
#include <string.h>
#include <stdlib.h>  //For atoi, exit
#include <unistd.h> //For close(sock)
#include <sys/ioctl.h> //For ioctl() Non Blocking mode
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "../../common.h"  //For TCP_Port

#define MAX_CONN 10 //Max n� of connection in queue

int s,s_aux;
struct sockaddr_in server, client;
unsigned int ClientAdrrSize2 = sizeof(client); 

int InitiaServerTCP ()
{
    // Create Socket	
	s = socket(AF_INET, SOCK_STREAM,0);
		if (s < 0) {perror("bind"); exit(1);}
	
	//Asign our own(server) address 
	server.sin_family = AF_INET;
    server.sin_port = htons(atoi(TCP_PORT)); //Port
    server.sin_addr.s_addr = htonl(INADDR_ANY);  //IP
	
	//Connect server to socket	
	if( bind(s,(struct sockaddr*)&server, sizeof(server)) != -1) 	
		printf("\n\aServer on listening TCP port: %s\n",TCP_PORT);  
	//Set the max n� of connection in queue. We�ll go attending with accept
	listen(s, MAX_CONN);
	//Wait some connection (with connect in client) 
	//and when is seccessful return a new descriptor socket which is only for the connection accepted
	printf("...Waiting to initialize some TCP connection...\n");
	s_aux = accept (s,(struct sockaddr*) &client, &ClientAdrrSize2);
	printf("Connection TCP initialized with client: %s\n", inet_ntoa(client.sin_addr)); 
		
	return 1;
}	

//Blocking mode (mode 1: Non blocking mode, mode 0: Blocking mode)
int BlockingMode (int mode)
{
	ioctl(s_aux, FIONBIO, (char *) & mode);
	return 1;
}
	
//Receive TCPF (TCPFinalize) or similars
int ReceiveTCP (char *cad)
{
	int r;
	r = recv(s_aux,cad, CADSIZETCP, 0);	
	//if (r != -1)
	//	fprintf(stderr,"<-Recibido: %s\n", cad);	
	return r;			
}

//Sender TCPF (TCP Finalize) or similar
int SenderTCP(char *cad)
{
	char se;
	//Send cad to server
	se = send(s_aux, cad, CADSIZETCP, 0);
	//if (se != -1)
	//	fprintf(stderr,"\n\n->Enviando: %s\n",cad);	
	return se;
}


//Send normally Statistic File
int SendTCPSpeechFile()
{
	FILE *fp_Speech=NULL; //File Pointer Speech	
	char cad[150];	
	
	fp_Speech = fopen("FichStat.txt", "rb"); 	
	//Put pointer before of end 
	fseek(fp_Speech, -150L, SEEK_END); 
	
	fread(cad, sizeof(char), 150, fp_Speech);	
	if (send(s_aux,cad,strlen(cad),0) == -1)	perror("Error sendto");
	fclose(fp_Speech);
	
	return 1;
}

	
int FinalizeTCP ()
{
	close(s_aux);
	close(s);	
	return 1;
}    
