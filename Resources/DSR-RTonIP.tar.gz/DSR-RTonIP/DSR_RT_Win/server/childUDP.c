/*******************************************************
*	AUTOR: 		Juan Andr�s Morales Cordovilla (&Timo Bauman) 
*				For the Granada University. July 2006
*	NAME:		cchildUDP.c ( Child UDP)
*	DESCRIPTION: 	Code of the proyect DSR-RT. 
*				It�s the code executed by the process childUDP
				This process is started by fatherTCP
**********************************************************/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h> //for read()
#include <signal.h> //To kill()
#include <sys/time.h> //for timeval

#include "../common.h"  //For size of rtpPacket, for  SIGSERVER
#include "serverUDP/serverembedUDP.h" // UDP receiver functions
#include "decoder/decoderembed.h" 	// for the embeddable decoder
#include "RecognVAD/RecognVAD.h" //for RecognVAD()
#include "serverTCP/serverembedTCP.h" //for sendTCP
#include "statistic/statistic.h"	//For struct info_frame
#define NITER 5000 //For time

int g_tube[2];	//global  to be  able access SigHandler
int g_stop=0;	//global  to be  able access SigHandler

void SigHandler(int sig)
{
	char cad[20];
	read(g_tube[0], cad, sizeof(cad)); //read non blocking mode
	
	if(strcmp(cad,"UDPF")==0)	//UDP Finalize
	{		
		g_stop=1;			
	}	
}


/***************************************
*	MAIN FUNCTION OF THIS MODULE
*
*	Receive UDP-RTP packet, decoder, recognizer, SendTCP result.
***************************************/
void childUDP(int *tube)
{
	//RECEIVER & DECODER&RECOGNITION VARIABLES	
	rtpPacket PacketToProcess[BUFFER_SIZE]; //Where receiver packet the payloads to be written
	int NumPacket;	//Num Packet-RTP to write
	int i;	
	int RecognDone=0;	
	unsigned char *framebuffer=NULL;  // this is where the decoded data ends up
	int frames;  //Num frames decode (2,1 or -1)		
	char *recognition_result;
	int nini=0, nfini=0; //for statistic fich	
	//struct timeval tini[NITER], tfin[NITER]; long j=0;
	
	
	//Asign SigHandler function	
	g_tube[0]=tube[0]; g_tube[1]=tube[1];	//to comunicate with father and SigHandler	
	signal(SIGSERVER, SigHandler);
	
	//INITIALIZE	
	InitiaReceiverUDP ();			 
	decoder_initialize();
	IniPrintStatisticFich();
	InitiaRecognVAD ();
	
	fprintf(stderr,"\nChildUDP ready to receive\n");	
	
	//MAIN
	do
	{
		
		NumPacket=ReceiverUDP(PacketToProcess);	//In blocking mode		
		for (i=0; i<NumPacket; i++)
		{
			
			frames = decode_two_frames(&PacketToProcess[i], &framebuffer);				
			//gettimeofday(&tini[j], NULL);
			RecognDone=RecognVAD(framebuffer, frames, &recognition_result);			
			//gettimeofday(&tfin[j], NULL); j++;
			
			if(RecognDone==1)
			{
				SenderTCP(recognition_result);
				nfini=PacketToProcess[i].sequence_number;	
				PrintStatisticFich (recognition_result, nini, nfini);
				nini=nfini;
				fprintf(stderr,"\n.....CLIENT SAID: %s....\n\n", recognition_result); 
				fflush(stderr);								
			}
		}
		
		
	} while(g_stop==0);
	
	fprintf(stderr,"\n\nTotal pair-HTKcoeffs received: %d", PacketToProcess[0].sequence_number);
 	
	//Termin	
	decoder_finalize();
	FinPrintStatisticFich();
	TerminReceiverUDP();	
	FinalizeRecognVAD ();
	//TimeStatistic(tini, tfin, j-1); j=0;
}
