//Prepare the recognizer
int SetRecognizer ();

// initialize recognition
void recognizer_initialize(HTK_DataFrame *data);

// feed data into the recognizer
// inputbuffer: pointer to 14 * sizeof(float) chars of unpacked data
// result: possible result of the recognition or NULL (currently always NULL)
//         this allows to implement incremental recognition in the future
void recognize();

// finalize the recognizer and get additional results or NULL
void recognizer_finalize(char **result);

int CloseRecogn ();
