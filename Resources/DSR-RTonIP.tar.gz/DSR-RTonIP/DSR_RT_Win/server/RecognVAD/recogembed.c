//recogembed.c (Recognition embed) (Part of DSR-RT. Granada Universty)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>	//for memcpy
#include <math.h>
#include "../../common.h"  //for PrintVoice ()
#include "../decoder/decoderembed.h"	// for the header of decoder	


#define RECOGNIZEMODE 1	//0: trainning, 1: recognition

#define LENGTHWORDMAX 110	//n� of frames in one word
#define LENGTHWORDNAME 20	//max n� of letter of the word 
FILE *HTK_file=NULL;
int cword, i, j;	//count of words, count_frame_test,  count_frame_referent   	


#if RECOGNIZEMODE
#define NREFFILE 8	//n� of reference files
#define NTotalWords 84 //n� of all words in all trainning words 
char NameRefFiles[NREFFILE][30]={"referFILES/numportJuan.htk","referFILES/numportJaume.htk",
								"referFILES/numportJaume2.htk","referFILES/numportJaume3.htk", 
								"referFILES/numportJaume4.htk",	"referFILES/numportFina.htk",
								"referFILES/numportPepe.htk","referFILES/numportMama.htk"};	//Names of the reference files
								
int NTrainWords[NREFFILE]={22,8,10,4,3,22,4,11};	//n� of training words in a reference file

int lengthword[NTotalWords];  //n� of frames that defines a word
HTK_DataFrame words[NTotalWords][LENGTHWORDMAX];	
double gactual[NTotalWords][LENGTHWORDMAX];
double gprevious[NTotalWords][LENGTHWORDMAX];
double dactual[NTotalWords][LENGTHWORDMAX];
char WordName[NTotalWords][LENGTHWORDNAME];	


#else
#define NTRAINWORDS 11	//It�s the n� of words really written in reference File. Usually -1 than the length of words said
int lengthword[NTRAINWORDS];	//The same length than NTRAINWORDS
char NameTrainFiles[30]={"numportMama.htk"};
HTK_DataFrame words[11][LENGTHWORDMAX];	//Words said. This and the next have to have the same length
//The last word always is PARA.											
char TrainWordName[11][LENGTHWORDNAME]={{"DOSm\0"}, 
										{"TRESm\0"}, {"SIETEm\0"},
										{"NUEVEm\0"},  {"ONCEm\0"},
										{"DOCEm\0"}, {"TRECEm\0"}, {"CATORCEm\0"},
										{"QUINCEm\0"}, 
										{"DIECINUEVEm\0"}, 
										{"PARA\0"}};									
#endif

/////////////////////////////////////////// RECOGNIZE MODE Dynamic Time Warping /////////////////////////////////////////////////////
#if RECOGNIZEMODE

/*Read the reference Data-Words from  files*/
int SetRecognizer ()
{
	int n, ini=0;
	
	//Save Words name, length of frames and frames
	for (n=0; n<NREFFILE; n++)
	{
		HTK_file = fopen(NameRefFiles[n], "rb");		
		for (cword=ini; cword<ini+NTrainWords[n]; cword++)
		{
			fread(&WordName[cword][0], 1, LENGTHWORDNAME, HTK_file);		
			fread(&lengthword[cword], sizeof(int), 1, HTK_file);
			for(i=0; i<lengthword[cword]; i++)
				fread(&words[cword][i].c1, sizeof(HTK_DataFrame), 1, HTK_file);		
		}		
		fclose(HTK_file);
		ini+=NTrainWords[n];	
	}	
	
	return 0;	
	

}

/*Obtain the actual distance towards each frames*/
void Dist (HTK_DataFrame *data)
{
	for(cword=0; cword<NTotalWords; cword++)
	{
		for(j=0; j<lengthword[cword]; j++)
		{
			dactual[cword][j]=sqrt(pow((words[cword][j].c1-data->c1), 2)+
								pow((words[cword][j].c2-data->c2), 2)+
								pow((words[cword][j].c3-data->c3), 2)+										
								pow((words[cword][j].c4-data->c4), 2)+
								pow((words[cword][j].c5-data->c5), 2)+
								pow((words[cword][j].c6-data->c6), 2)+
								pow((words[cword][j].c7-data->c7), 2)+
								pow((words[cword][j].c8-data->c8), 2)+
								pow((words[cword][j].c9-data->c9), 2)+
								pow((words[cword][j].c10-data->c10), 2)+
								pow((words[cword][j].c11-data->c11), 2)+
								//pow((words[cword][j].c0-data->c0), 2)+
								pow((words[cword][j].c12-data->c12), 2));				
		}			
	}		
}

/*Obtain, resorttly, the actual  accumulate distance for a spefic i*/	
void DistAccumulate()
{
	double min;
	
	//Obtain the actual  accumulate distance
	for(cword=0; cword<NTotalWords; cword++)
	{ 
		//for j=0
		gactual[cword][0]=gprevious[cword][0]+dactual[cword][0];
	
		//for j=1, 2, ...
		for(j=1; j<lengthword[cword]; j++)
		{
			
			//find the minimum
			min=gprevious[cword][j];	//add frame		
			if(min>gprevious[cword][j-1])
				min=gprevious[cword][j-1]; 	//normal progression
			if(min>gactual[cword][j-1])
				min=gactual[cword][j-1];	//delete frame
			
			gactual[cword][j]=min+dactual[cword][j];	
			
		}		 	
	}
	
	//Fill  the previous  accumulate distance for the next iteration
	for(cword=0; cword<NTotalWords; cword++)
		for(j=0; j<lengthword[cword]; j++)
			gprevious[cword][j]=gactual[cword][j];	
}				

/*Obtain the previous  accumulate distance for i=0*/				
void recognizer_initialize(HTK_DataFrame *data)
{
	i=0;	
	Dist(data);		
	for(cword=0; cword<NTotalWords; cword++)
	{
		gprevious[cword][0]=dactual[cword][0];
		for(j=1; j<lengthword[cword]; j++)		
			gprevious[cword][j]=gprevious[cword][j-1]+dactual[cword][j];		
	}
	//PrintVoice ((int)(data->logE)); fprintf(stderr,"\n");	
}



/***************************************
*	MAIN FUNCTION OF THIS MODULE
*
*	Main function of Dynamic Time Warping, is called many times
***************************************/
void recognize(HTK_DataFrame *data)
{
	i++;
	Dist(data);			
	DistAccumulate();
	//PrintVoice ((int)(data->logE)); fprintf(stderr,"\n");		
}

/*Obtain the pronounced word*/
void recognizer_finalize(char **result)
{
	double min, min2;
	double totaldistance[NTotalWords];
	int word;	
	
	//Obtain the normalized total distance 
	for(cword=0; cword<NTotalWords; cword++)
		totaldistance[cword]=gactual[cword][lengthword[cword]-1];			
	
	
	//Obtain the min accumulate distance, then, the word said
	min=totaldistance[0];
	word=0;		
	for (cword=1; cword<NTotalWords; cword++)
	{
		if (totaldistance[cword]<min)
		{
			min=totaldistance[cword];
			word=cword;						
		}
	}	
	
	min2=1000000;			
	for (cword=0; cword<NTotalWords; cword++)
	{
		if(cword!=word)
		{
			if (totaldistance[cword]<min2)
				min2=totaldistance[cword];									
		}
	}
	
	fprintf(stderr,"\nDistance of min %.1f with the second best: %.1f", min, (min2-min));	
	
	*result=WordName[word];

}

/*Finish all recognition */
int CloseRecogn ()
{
	return 0;
}

///////////////////////////////////////// TRAINING MODE ////////////////////////////////////////////////////////	
#else 
//Write at the begining  of reference file NTRAINWORDS 
int SetRecognizer ()
{
	fprintf(stderr,"\nTRAINNING MODE\n"); fflush(stderr);
	HTK_file = fopen(NameTrainFiles, "wb");		
	cword=0;
	return 0;	
}

//Start a new word
void recognizer_initialize(HTK_DataFrame *data)
{
	i=0;
	memcpy(&words[cword][i].c1, &data->c1, sizeof(HTK_DataFrame));	
	//PrintVoice ((int)(data->logE)); fprintf(stderr,"\n");		
}

/***************************************
*	MAIN FUNCTION OF THIS MODULE
*
*	Main function of DTW Trainning, is called many times
***************************************/
void recognize(HTK_DataFrame *data)
{
	i++;
	if(i<LENGTHWORDMAX)
		memcpy(&words[cword][i].c1, &data->c1, sizeof(HTK_DataFrame));
			
	//PrintVoice ((int)(data->logE)); fprintf(stderr,"\n");		
}	

//Finish the word and write in fich: name, size & data of the word	
void recognizer_finalize (char **result)
{
	if(cword<NTRAINWORDS)
	{
		lengthword[cword]=i;
		fprintf(stderr,"Writting the Word n�: %d with a length of %d\n", cword, lengthword[cword]);	
		fwrite(&TrainWordName[cword][0], 1, LENGTHWORDNAME, HTK_file);
		fwrite(&lengthword[cword], sizeof(int), 1, HTK_file);	
		for(i=0; i<lengthword[cword]; i++)
			fwrite(&words[cword][i].c1, sizeof(HTK_DataFrame), 1, HTK_file);	
	}
	
	*result=TrainWordName[cword];
	cword++;	
}

//Finish training
int CloseRecogn()
{
	fclose(HTK_file);	
	return 0;
}
#endif

