//static.h
#define SIZEFRAMEPAIRS 5000 

typedef struct info_frame
{
	int CRC_error;
	int arrived;
}info_framePairs;

void IniPrintStatisticFich();
void PrintStatisticFich (char *recognition_result, int nini, int nfini);
void FinPrintStatisticFich();
