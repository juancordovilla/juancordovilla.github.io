/*******************************************************
*	AUTOR: 		Juan Andr�s Morales Cordovilla (&Timo Bauman) 
*				For the Granada University. July 2006
*	NAME:		cchildUDP.c (Client Child UDP)
*	DESCRIPTION: 	Code of the proyect DSR-RT. 
*				It�s the code executed by the process cchildUDP
				This process is started by cfatherTCP
**********************************************************/


#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <signal.h> //To stop server
#include <unistd.h> // usleep()
#include <sys/time.h> //for timeval

#include "recordlib/pablio.h"  //for rec
#include "coder/coderembed.h" // for the embeddable coder
#include "fe/feembed.h" // for the embeddable feature-extractor
#include "clientUDP/clientembedUDP.h" //for sender
#include "VAD/VAD.h" //for VAD
#include "../common.h"  //for  PrintVoice ()

//OPTIONS
#define SAMPLE_RATE (8000) //Sample frequenzy in Hz 
#define N_TOTALSILENT (30) //BUFFER_SIZE is the length of buffer in server in udp-rtp correction, is usually 8


int g_tube[2];	//global  to be  able access SigHandler
int g_stop=0;	//global  to be  able access SigHandler
extern unsigned char COMPRESSEDTOTALSILENT[12];  //see common.c

//When receives from father a signal execute this function
void SigHandler(int sig)
{
	char cad[20];
		
	read(g_tube[0], cad, sizeof(cad)); //read non blocking mode	
	if(strcmp(cad,"UDPF")==0)	//UDP Finalize
	{		
		g_stop=1;		
	}	
	
}

/***************************************
*	MAIN FUNCTION OF THIS MODULE
*
*	record samples. obtein vector coef, coder and senderUDP
***************************************/
void cchildUDP(int *tube, char *serverIP)
{
	//RECORD+FE+CODER+SENDER VARIABLES	
	short initbuffer[120];	// this is where rec reads initialization data into  
	short rawbufferA[80], rawbufferB[80];		// this is where rec reads data into  
	HTK_DataFrame framebuffer[2]; 	// this is where the frames end up
	HTK_DataFrame framebufferToSend[2];  //the frames with Voice  
	unsigned char compressedframes[12]; // this is where the coded data ends up. Is the frame-pair    
	int TotalSent=0; //Number of packet (two_frames) sent 
	PaError  err;	
	PABLIO_Stream *aStream=NULL; //Identify the Portaudio  operation	
	int VADNum=0; 	//Number of frames what are voice		

	
	//Asign SigHandler function
	g_tube[0]=tube[0]; g_tube[1]=tube[1];	//to comunicate with father and SigHandler
	signal(SIGCLIENT, SigHandler);	
	
	//INITIALIZE (first initialize the furthest program to be always ready)
	InitiaSenderUDP(serverIP);	
	coder_initialize();	
	
	
	//Initialize record		
	err = OpenAudioStream( &aStream, SAMPLE_RATE, paInt16,
							(PABLIO_READ | PABLIO_MONO) );//PortAudio, mode blocking I/O 
    if( err != paNoError ) {perror("OpenAudioStream "); exit(1);} ;	
	fprintf(stderr,"\nNow recording.....\n\n");		
	ReadAudioStream( aStream, initbuffer, 120);		
	
	fe_initialize(initbuffer);
			

	//MAIN			
	while(g_stop==0)	
	{
		
		//FE get framebuffer[0]		
		ReadAudioStream(aStream, rawbufferA, 80);		
		fextract(rawbufferA, &framebuffer[0]);	
		
		//FE get framebuffer[1]		
		ReadAudioStream( aStream, rawbufferB, 80);					
		fextract(rawbufferB, &framebuffer[1]);			
		
		//VAD		
		VADNum=VAD(framebuffer, 2, framebufferToSend);		
		
		switch(VADNum)
		{	
			case -1: //Finish the word		
				SenderUDPQuickly(COMPRESSEDTOTALSILENT, N_TOTALSILENT);				
				TotalSent+=N_TOTALSILENT;
				
				break;
			
			case 0:	//There isn�t voice			
				break;
			
			default: //There is voice
				//Code get  compressedframes to send				
				code_two_frames(framebufferToSend, compressedframes);	
			
				//Send compressedframes							
				SenderUDP(compressedframes);						
				TotalSent++;				
				break;			
		
		}		
		PrintVoice ((int)(framebuffer[0].logE)); //fprintf(stderr,"\n");		
		//PrintVoice ((int)(framebuffer[1].logE)); fprintf(stderr,"\n");	
			
	}
	
	// FINALIZE
	fe_finalize();
	coder_finalize();
	TerminSenderUDP ();	
	CloseAudioStream( aStream );
	//
	
	fprintf(stderr,"\n\nTotal code-HTKcoeffs-pairs sent via UDP: %d\n", TotalSent);	
}			
