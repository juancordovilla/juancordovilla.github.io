/*******************************************************
*	AUTOR: 		Juan Andr�s Morales Cordovilla (&Timo Bauman) 
*				For the Granada University. July 2006
*	NAME:		cfatherTCP.c (Client Father TCP)
*	DESCRIPTION: 	Code of the proyect DSR-RT. 
*				It�s the first code that is executed by the Client
*				Program (cfatherTCP).
**********************************************************/

#include <stdio.h>
#include <stdlib.h> //For exit()
#include <string.h> //For strcpy
#include <unistd.h>
#include <sys/wait.h> //For wait()
#include <unistd.h> // usleep()
#include <signal.h>	// for kill(), sigsuspend(), others
#include <fcntl.h> //For fcntl, non blocking tube
#include "clientTCP/clientembedTCP.h" //for TCP conecction
#include "../common.h"  //for  SIGNALCLIENT

void cchildUDP(int *tube, char *serverIP);

int main(int argc, char *argv[]) 
{
	//If few enter�s parameter
	if(argc!=2)
	{
		fprintf(stderr, "\n**************** ERROR IN USAGE *********************"); 
		fprintf(stderr, "\n									             		");
		fprintf(stderr, "\n You have to add the IP of the server, example:		");
		fprintf(stderr, "\n												 		"); 
		fprintf(stderr, "\n		>cfatherTCP 192.168.1.66	               		");
		fprintf(stderr, "\n									             		");
		fprintf(stderr, "\n*****************************************************"); 
		fflush(stderr);
		return -1;
	}
	
	int pidchild, tube[2];
	
	//Initializace a TCP connections	
	InitiaClientTCP(argv[1]);	
	BlockingModeTCP(0); //put TCP in  blocking mode
	
	//Prepare child UDP    
	pipe(tube);	//Open  where father and children write and read common dates 
	fcntl(tube[0], F_SETFL, O_NONBLOCK); //tube in non block mode	
	
	//Execute child function
	if ((pidchild=fork())==0)
	{
		cchildUDP(tube, argv[1]);  //CHILD, tube[0] to read and tube[1] to write and IPserver
		fprintf(stderr,"\nTERMINATED CHILDREN \n");
		exit(0);
	}	
	
	/*********************************************
	*	MAIN FUNCTION OF THIS MODULE (father)
	*	wait to receive TCP result of arecognition
	*	and print by screen
	*********************************************/
	else
	{	
		char cad[CADSIZETCP];		
		int status;			
		
		//To terminate say PARA
		fprintf(stderr,"\n\n****************************");
		fprintf(stderr,  "\n** Say 'PARA' to finalize **");
		fprintf(stderr,  "\n****************************\n\n");
		
		do 
		{
			if(ReceiveTCP(cad)!=-1)	//in blocking mode
				fprintf(stderr,"\n...... YOU SAID: %s ....\n\n",  cad);	
			fflush(stderr);	
		}while(strcmp(cad,"PARA")!=0);
				
		//Say to server Bye
		strcpy(cad,"TCPF");	
		SenderTCP(cad);		
		
		//Say to child UDP stop
		strcpy(cad,"UDPF");
		write(tube[1], cad, sizeof(cad));		
		kill(pidchild, SIGCLIENT);
		
				
		while(wait(&status) != pidchild); 	//Father Waits to Finalize Child to avoid zombies	
		
		close(tube[0]); close(tube[1]);	//Close tube connector			
			
		fprintf(stderr,"\n... Receiving TCPSpeechFile ..");
		ReceiveTCPSpeechFile();
		
		//Close TCP connections
		FinalizeTCP();
		fprintf(stderr,"\nTERMINATED FATHER \n");	
				
	}
	
	return 1;
}
