//clientembed.h

int InitiaClientTCP(char *ServerIP);
int BlockingModeTCP (int mode);
int ReceiveTCP (char *cad);
int SenderTCP(char *cad);
int ReceiveTCPSpeechFile();
int FinalizeTCP();
