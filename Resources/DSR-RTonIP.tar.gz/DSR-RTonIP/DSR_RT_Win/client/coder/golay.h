/******************************************************************************
*
*      ETSI STQ WI007 DSR Front-End Compression Algorithm
*      C-language software implementation 
*      Version 1.1.3   May, 2003
*
* 
******************************************************************************/


unsigned short golay_encode(unsigned short data);
int golay_errors(unsigned short *data, unsigned short *crc);
unsigned char crc_encode(unsigned char data[]);

// Calculate the crc of data[] and return TRUE if it equals the given crc. 
// Otherwise return FALSE
int crc_errors(unsigned char data[], unsigned char crc);
