//VAD.c (Voice Activity Detector) (Part of DSR-RT. Granada Universty)

#include <stdio.h>
#include <string.h>	//for memcpy
#include "../coder/coderembed.h"	// for the HTK_ DataFrame of decoder	

#define LIMIT1 19.5	//when a coeff (LogE) pass this limit  there�s voice
#define LIMIT2 18.0 //after speak, only finish when pass this limit
#define COEFF logE //coeff to compare with LIMIT
#define QUEUEINI 8	//n� of frame ( before pass de LIMIT1) that are parts of the voice�s wave 
#define QUEUEWAIT 13 //After pass LIMIT2 wait a bit to see if really the logE is finishing word or may rise quickly cause of other syllable  
#define RISING 1
#define DROPPING -1
#define DOWN 0

int status=DOWN;
HTK_DataFrame buff[QUEUEINI];  //buff[0] is the oldest, buff[QUEUELENGTH-1] is the most recent
extern unsigned char COMPRESSEDTOTALSILENT[12];  //see common.c
int VADCount;
int j;
int n=0;


//buff[0] is the oldest, buff[QUEUELENGTH-1] is the most recent
void fillbuffer (HTK_DataFrame  *data)
{
	int i;
	for (i=0; i<QUEUEINI-1; i++)
		memcpy(&buff[i].c1, &buff[i+1].c1,sizeof(HTK_DataFrame));
	memcpy(&buff[QUEUEINI-1].c1, &data->c1,sizeof(HTK_DataFrame));	
}

//Put Frame in order
void PutFrameToSend (HTK_DataFrame *frame, HTK_DataFrame *framebufferToSend)
{
	memcpy(&framebufferToSend[j].c1, &frame->c1, sizeof(HTK_DataFrame));	
    VADCount++;	
}


/***************************************
*	MAIN FUNCTION OF THIS MODULE
*
* 	Return 0: if there isn�t voice,
* 	Return 1 , 2,.... the number of Voice, Return -1: if finish the word
* 	in framebufferToSend will put COMPRESSEDTOTALSILENT if there isn�t voice
**************************************************************************/
int VAD(HTK_DataFrame  *framebuffer, int Numframes, HTK_DataFrame  *framebufferToSend)
{	
	VADCount=0;
	memcpy(framebufferToSend, COMPRESSEDTOTALSILENT, 12);
	
	//fprintf(stderr, "%5.1f ", buff[QUEUEINI-1].COEFF);
	
	for (j = 0; j < Numframes; j++) 
	{
		
		fillbuffer(&framebuffer[j]);
		
		switch(status) //normally see stautus of the log E  ( buff[QUEUELENGTH-1].COEFF )	
		{	
			case DOWN: //There isn�t voice�s wave
				if (buff[QUEUEINI-1].COEFF > LIMIT1)
				{
					PutFrameToSend(&buff[0], framebufferToSend);
					n++; 
					if (n==QUEUEINI) 
						{n=0; status=RISING;}									
				}
				else{}
				break;			
			
			case RISING: //There is voice�s wave
				if (buff[QUEUEINI-1].COEFF < LIMIT2)
				{
					PutFrameToSend(&buff[0], framebufferToSend); 				
					status=DROPPING;					
				}
				else { PutFrameToSend(&buff[0], framebufferToSend);}					
				break;				
			
			case DROPPING: //The voice�s wave is dropping and may finish the word or not
				if (buff[QUEUEINI-1].COEFF < LIMIT2)
				{
					PutFrameToSend(&buff[0], framebufferToSend); 
					n++; 
					if (n==QUEUEWAIT) 
						{n=0; status=DOWN; return -1; }	//Recognition done				
				}
				//Come another syllabe and is not  the end of the word
				else {PutFrameToSend(&buff[0], framebufferToSend);  n=0; status=RISING; }
				break;
				
			default:
				fprintf(stderr, "ERROR VAD STATUS");
				break;
				
		}
	}
	return VADCount;	//Non recognition done
}

