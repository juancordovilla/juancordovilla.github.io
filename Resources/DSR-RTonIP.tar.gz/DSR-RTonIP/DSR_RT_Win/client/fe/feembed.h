//
void fe_initialize(short *inputbuffer);
void fe_get_htk_header(unsigned char *header);
void fextract(short *inputbuffer, HTK_DataFrame *outputbuffer);
void fe_finalize();

