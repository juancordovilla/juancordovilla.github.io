//common.h (common & important constants of client & server) (Part of DSR-RT. Granada Universty)

//Signal
#define SIGCLIENT SIGUSR1
#define SIGSERVER SIGUSR2

//Functions
void PrintVoice (int intensity);
struct timeval restaTiempo(struct timeval *t1, struct timeval *t2);
void TimeStatistic (struct timeval *tini, struct timeval *tfin, long imax);

//TCP, UCP Port
#define TCP_PORT "11500"
#define UDP_PORT "11500"
#define CADSIZETCP 20	//For communication TCP


//Rtp protocol
#define PAYLOAD_SIZE 12
#define BUFFER_SIZE 8	//max n� of items in the recive-buffer
typedef struct {
  unsigned char flags;
  unsigned char payload_type;
  unsigned int sequence_number;
  unsigned long timestamp;
  unsigned long synchronization_source;
  unsigned char payload[PAYLOAD_SIZE];
} rtpPacket;
