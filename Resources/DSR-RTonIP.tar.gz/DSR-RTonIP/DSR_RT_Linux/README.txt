/*******************************************************
*	AUTOR: 		Juan Andr�s Morales Cordovilla (&Timo Bauman) 
*			For the Granada University. July 2006
*	DESCRIPTION: 	It�s a brief description of how use 
*			the DSR-RT (Distributed Speech Recognition of Real Time)
**********************************************************/

- To compile: use the makefiles (>make)


---------------- RECOGNITION MODE --------------------
- Use Server: >./fatherTCP 

- Use Client: >./cfatherTCP 192.168.1.66 (and start to said the numbers
from CERO to VEINTE (in Spanish) and PARA to close the system).

* VERY IMPORTANT NOTE : To have a good recogniton we recommend strongly that the client
must be the same computer used in the trainning. In other case adjust the 4 constant (LIMIT1, 
LIMIT2, QUEUEINI, QUEUEWAIT) of the client�s VAD.
 
 
---------------- TRAINNING MODE --------------------
- Use Server: Change the flag of recogembed.c RECOGNIZEMODE to 0, write the names of the words, correct
the length of the 4 vectors and write the name of new file-trainning. Re-compile and use like before.

-Use Cliente: use like before (and start to said the words in the same order
that you wrote in server).

* IMPORTANT NOTE: After trainnig, to include the new file-trainning in the recognition, change the necesary at the
begining of definitions of recogembed.c, change the flag RECOGNIZEMODE to 1 and re-compile.

* For more information see the paper of this project.
