//Outside there is some tipical files of patter error that are used by the 
//senderUDP to generate error. 

#include <stdio.h>
#include <string.h>

FILE *fp_error=NULL; 
//Importants files of patter error
/*10 1
20 1
30 2
40 2
50 4*/

//Example of reading  files of patter error
void main ()
{
	fp_error = fopen( "../PatterError/mask_50_4", "r" );
	long i=0;
	
	fseek( fp_error, 0L, SEEK_SET );
	while (feof(fp_error)==0){
		i++;		
		printf( "%d", fgetc(fp_error));
	}
	printf( "\n\n***************************************** %ld **********************\n\n ",i);	
			
	fclose(fp_error);
}