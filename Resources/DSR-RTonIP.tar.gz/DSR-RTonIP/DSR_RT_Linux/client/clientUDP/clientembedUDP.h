//SENDEREMBED.h

int InitiaSenderUDP (char *ServerIP); 
int SenderUDP(unsigned char *string);
void SenderUDPQuickly (unsigned char *string, int times);
int TerminSenderUDP();

