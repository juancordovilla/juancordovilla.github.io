//clientembedUDP.c (Part of DSR-RT. Granada Universty)

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h> //For close(sock)
#include "../../common.h" //For rtpPacket

//Comunication variables
int sock;
struct sockaddr_in client, server;  
unsigned int ServerAdrrSize = sizeof(server);  

//Error simulation 
FILE *fp_err=NULL; 

//Real time protocoll
rtpPacket sendPacket;
char GlobalServerIP[16];
	
int InitiaSenderUDP (char *ServerIP) 
{
	//First sequence_number of packet sent
	sendPacket.sequence_number=0; 
	
	// Create Socket
    sock = socket(AF_INET,SOCK_DGRAM,0);
    if (sock < 0) {perror("sock"); exit(1);} 
	
	//Asign our own(client) address 	
    client.sin_family = AF_INET;//Domain Internet
    client.sin_port = htons(0); //Port
    client.sin_addr.s_addr = htonl(INADDR_ANY); //any IP in this host	
	
	
	//Connect Client to socket
    if( bind(sock,(struct sockaddr*)&client, sizeof(client)) < 0) {perror("bind"); exit(1);} 
	
	//Asign server address 		
	memcpy(GlobalServerIP, ServerIP, strlen(ServerIP) );	
	server.sin_family = AF_INET; //Domain Internet 
	server.sin_port = htons(atoi(UDP_PORT)); //Port
	server.sin_addr.s_addr = inet_addr(GlobalServerIP); //IP
	
	fp_err = fopen( "PatternError/mask_50_4", "r" );	//Error Simulation	
	
	return 1;
}

/***************************************
*	MAIN FUNCTION OF THIS MODULE
*	
*	Send one packet UDP-RTP. The first sequence_number is 0
***************************************/
int SenderUDP (unsigned char *string)
{
	memcpy(sendPacket.payload,string,PAYLOAD_SIZE);
	
	//if(fgetc(fp_err)==0)
	{
		//Send String to server
		sendto(sock,&(sendPacket),sizeof(sendPacket),0,(struct sockaddr*)&server,sizeof(server));
	}	
	
	sendPacket.sequence_number++;
	
	return 1;
}

void SenderUDPQuickly (unsigned char *string, int times)
{
	int i;
	for(i=0; i<times; i++)
		SenderUDP(string);	
}

int TerminSenderUDP ()
{
	//Close socket
	close(sock);
	fclose(fp_err);  //Error Simulation
	return 1;
}
