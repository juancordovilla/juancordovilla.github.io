//clientembedTCP.c (Part of DSR-RT. Granada Universty)

#include <sys/timeb.h> // for funcition sleep
#include <stdio.h>
#include <string.h>
#include <stdlib.h>  //For atoi, exit
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h> //For close(sock)
#include <sys/ioctl.h> //For ioctl() Non Blocking mode
#include "../../common.h"  //For TCP_Port

int s;
struct sockaddr_in client,server; 
int *sd;
char GlobalServerIP[16];


int InitiaClientTCP(char *ServerIP) 
{
	// Create Socket
	s = socket(AF_INET,SOCK_STREAM,0);	 
	if (s < 0) {perror("sock"); exit(1);}
	//Asign our own(client) address 		
	client.sin_family = AF_INET;
    client.sin_port = htons(0); 
    client.sin_addr.s_addr = htonl(INADDR_ANY);
	//Connect Client to socket 	
	if( bind(s,(struct sockaddr*)&client, sizeof(client)) < 0) {perror("bind");} 	
	//Asign server address 
	memcpy(GlobalServerIP, ServerIP, strlen(ServerIP) );
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = inet_addr(GlobalServerIP); //IP
	server.sin_port = htons(atoi(TCP_PORT)); //Port	
	//Initialize conection with socket of server (accept() in server recognizes this) 
	fprintf(stderr,"\nPress to initialize TCP connection with DSR server: %s\n", GlobalServerIP); getchar();
	connect(s,(struct sockaddr*)&server,sizeof(server)); 	
	fprintf(stderr,"\nPress to start speech recognition via UDP..\n"); getchar();
	return 1;
} 

//Blocking mode TCP (mode 1: Non blocking mode, mode 0: Blocking mode)
int BlockingModeTCP (int mode)
{
	ioctl(s, FIONBIO, (char *) & mode);
	return 1;
}


//Receive TCPF (TCPFinalize) or similars
int ReceiveTCP (char *cad)
{
	int r;
	r = recv(s, cad, CADSIZETCP, 0);	
	//if (r != -1)
	//	fprintf(stderr,"\n<-Recibido: %s", cad);	
	return r;			
}

//Sender TCPF (TCP Finalize) or similar
int SenderTCP(char *cad)
{
	char se;
	//Send cad to server
	se = send(s, cad, CADSIZETCP, 0);
	//if (se != -1)
	//	fprintf(stderr,"\n->Enviando: %s, a: %s  en el puerto: %s",cad, GlobalServerIP, TCP_PORT);
	return se;
}


//Receive Speech File normally the statitic results of a prove
int ReceiveTCPSpeechFile()
{
	FILE *fp_Speech=NULL; //File Pointer Speech	
	char cad[150];
	
	if (recv(s,cad, sizeof(cad) ,0) == -1)	perror("Error recv");
	
	
	fp_Speech = fopen("FichStat.txt", "wb");
	if (fp_Speech == NULL)
		fprintf(stderr,"\nERROR: opening FichStat.txt");
	
	fwrite(cad, sizeof(char), strlen(cad), fp_Speech);	
	fprintf(stderr,"\n%s", cad);
	fclose(fp_Speech);
	
	return 1;
}

int FinalizeTCP ()
{
	close(s);
	return 1;
}



