//feembed.c (Front End embed based on ETSI ES-201-108) (Part of DSR-RT. Granada Universty)

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "FEfunc.h"
#include "fileio.h"
#include "../coder/coderembed.h"	// for the HTK_ DataFrame of decoder


//Definition of Front-end Parameters 
#define SAMPLING_FREQ_1           8  /*8kHz */
#define FRAME_LENGTH_1          200  /*25ms */
#define FRAME_SHIFT_1            80  /*10ms */

#define PRE_EMPHASIS           0.97
#define ENERGYFLOOR_FB        -50.0  /*0.0 */
#define ENERGYFLOOR_logE      -50.0  /*4.0 */
#define FFT_LENGTH_1            256
#define MAXWINDOWSIZE           512
#define NUM_CHANNELS             23
#define STARTING_FREQ_1        64.0  /*55.401825 */
#define NUM_CEP_COEFF            13  /* c1..c12 + c0 */

// Global Definitions and Macros
#define	BOOLEAN int


int i, TmpInt, CFBSize, CFBPointer;

long FrameLength, FrameShift, FFTLength, FrameCounter;
int SamplingFrequency;  /* SamplingFrequency */
float StartingFrequency;
float LogEnergy, StartingFrequency, EnergyFloor_FB,
  EnergyFloor_logE, FloatBuffer[MAXWINDOWSIZE + 1],
  FloatWindow[MAXWINDOWSIZE / 2], *pDCTMatrix, *CircFloatBuffer;

FFT_Window FirstWindow;

//Put samples into CircBuff
void put_into_float_buffer(short *inputbuffer, float *CircBuff, int BSize, int BPointer, int nSamples) {
  int i;
  for (i = 0; i < nSamples; i++) {
    CircBuff[BPointer] = (float) inputbuffer[i];
    BPointer = (BPointer + 1) % BSize;
  }
}


/*------------------------------------------------------------------------------
* int fe_initialize(short *inputbuffer)
* call this before using the extractor. initializes various buffers.
* For this, 120 audio-samples (15 ms) are needed
* parameters:
* short *inputbuffer: make sure, that it is possible to read 120 shorts from this buffer
-----------------------------------------------------------------*/
void fe_initialize(short *inputbuffer) {
  FrameLength = FRAME_LENGTH_1;
  FrameShift = FRAME_SHIFT_1;
  FFTLength = FFT_LENGTH_1;
  StartingFrequency = STARTING_FREQ_1;
  SamplingFrequency = 8000;
  FrameCounter = 0;

  /*----------------*/
  /* Initialization */
  /*----------------*/
  EnergyFloor_FB = (float) exp ((double) ENERGYFLOOR_FB);
  EnergyFloor_logE = (float) exp ((double) ENERGYFLOOR_logE);
//  InputByteOrder=NativeByteOrder;

  /*------------------------------------------------*/
  /* Memory allocation and initialization for input */
  /* circular float buffer                          */
  /*------------------------------------------------*/
  CFBSize=FrameLength+2;
  CircFloatBuffer=(float*)malloc(sizeof(float)*CFBSize);
  if ( !CircFloatBuffer ) {
    fprintf (stderr, "\nERROR: Memory allocation error occured!\r\n");
    exit(1);
  }
  CircFloatBuffer[0]=0.0;
  CircFloatBuffer[1]=0.0;
  CFBPointer=0;

  /*-------------------------------------------------------*/
  /* Initialization of FE data structures and input buffer */
  /*-------------------------------------------------------*/
  InitializeHamming (FloatWindow, (int) FrameLength);
  InitFFTWindows (&FirstWindow, StartingFrequency,
                         (float) SamplingFrequency, FFTLength, NUM_CHANNELS);
  ComputeTriangle (&FirstWindow);
  pDCTMatrix = InitDCTMatrix (NUM_CEP_COEFF, NUM_CHANNELS);

//  ReadWave(fp_in, CircFloatBuffer, CFBSize, CFBPointer+2, FrameLength-FrameShift,
   //              (SwapSpecified || InputByteOrder != NativeByteOrder));
  put_into_float_buffer(inputbuffer, CircFloatBuffer, CFBSize, CFBPointer + 2, FrameLength - FrameShift);

  DCOffsetFilter( CircFloatBuffer, CFBSize, &CFBPointer, FrameLength-FrameShift );

}


/***************************************************
*	MAIN FUNCTION OF THIS MODULE
*	
* 	extract the features of the 10ms 8khz audio stream given in the inputbuffer
* 	and put them into the outputbuffer
* 	parameters:
* 	short *inputbuffer: make sure, that it is possible to read 80 shorts from this buffer
* 	unsigned char *outputbuffer: make sure, that it is possible to write 14 floats into this buffer
******************************************************/
void fextract(short *inputbuffer, HTK_DataFrame *outputbuffer) 
{

  int i;

  put_into_float_buffer(inputbuffer, CircFloatBuffer, CFBSize, (CFBPointer + 2) % CFBSize, FrameShift);
  /*-------------------*/
  /* DC offset removal */
  /*-------------------*/
  DCOffsetFilter( CircFloatBuffer, CFBSize, &CFBPointer, FrameShift );

  /*------------------*/
  /* logE computation */
  /*------------------*/
  LogEnergy = 0.0;
  for (i = 0; i < FrameLength; i++)
    LogEnergy += CircFloatBuffer[(CFBPointer+i+3)%CFBSize] * CircFloatBuffer[(CFBPointer+i+3)%CFBSize];

  if (LogEnergy < EnergyFloor_logE)
    LogEnergy = ENERGYFLOOR_logE;
  else
    LogEnergy = (float) log ((double) LogEnergy);
	    
  /*-----------------------------------------------------*/
  /* Pre-emphasis, moving from circular to linear buffer */
  /*-----------------------------------------------------*/
  for (i = 0; i < FrameLength; i++)
    FloatBuffer[i] = CircFloatBuffer[(CFBPointer+i+3)%CFBSize] -

  PRE_EMPHASIS * CircFloatBuffer[(CFBPointer+i+2)%CFBSize];

  /*-----------*/
  /* Windowing */
  /*-----------*/
  Window (FloatBuffer, FloatWindow, (int) FrameLength);

  /*-----*/
  /* FFT */
  /*-----*/

  /* Zero padding */
  for (i = FrameLength; i < FFTLength; i++)
    FloatBuffer[i] = 0.0;

  /* Real valued, in-place split-radix FFT */
  TmpInt = (int) (log10 (FFTLength) / log10 (2));
  rfft (FloatBuffer, FFTLength, TmpInt); /*TmpInt = log2(FFTLength)*/

  /* Magnitude spectrum */
  FloatBuffer[0] = (float) fabs ((double) FloatBuffer[0]);  /* DC */
  for (i = 1; i < FFTLength / 2; i++)  /* pi/(N/2), 2pi/(N/2), ...,
    (N/2-1)*pi/(N/2) */
     FloatBuffer[i] = (float) sqrt ((double) FloatBuffer[i] *
                                    (double) FloatBuffer[i] +
                                    (double) FloatBuffer[FFTLength - i] *
                                    (double) FloatBuffer[FFTLength - i]);
  FloatBuffer[FFTLength / 2] = (float) fabs ((double) FloatBuffer[FFTLength / 2]);  /* pi/2 */

  /*---------------*/
  /* Mel filtering */
  /*---------------*/
  MelFilterBank (FloatBuffer, &FirstWindow);

  /*-------------------------------*/
  /* Natural logarithm computation */
  /*-------------------------------*/
  for (i = 0; i < NUM_CHANNELS; i++)
    if (FloatBuffer[i] < EnergyFloor_FB)
      FloatBuffer[i] = ENERGYFLOOR_FB;
    else
      FloatBuffer[i] = (float) log ((double) FloatBuffer[i]);

  /*---------------------------*/
  /* Discrete Cosine Transform */
  /*---------------------------*/
  DCT (FloatBuffer, pDCTMatrix, NUM_CEP_COEFF, NUM_CHANNELS);

  /*--------------------------------------*/
  /* Append logE after c0 or overwrite c0 */
  /*--------------------------------------*/
  FloatBuffer[NUM_CHANNELS + NUM_CEP_COEFF] = LogEnergy;

  /*---------------*/
  /* Output result */
  /*---------------*/  
    outputbuffer->c1 = FloatBuffer[NUM_CHANNELS + 0];
	outputbuffer->c2 = FloatBuffer[NUM_CHANNELS + 1];
	outputbuffer->c3 = FloatBuffer[NUM_CHANNELS + 2];
	outputbuffer->c4 = FloatBuffer[NUM_CHANNELS + 3];
	outputbuffer->c5 = FloatBuffer[NUM_CHANNELS + 4];
	outputbuffer->c6 = FloatBuffer[NUM_CHANNELS + 5];
	outputbuffer->c7 = FloatBuffer[NUM_CHANNELS + 6];
	outputbuffer->c8 = FloatBuffer[NUM_CHANNELS + 7];
	outputbuffer->c9 = FloatBuffer[NUM_CHANNELS + 8];
	outputbuffer->c10 = FloatBuffer[NUM_CHANNELS + 9];
	outputbuffer->c11 = FloatBuffer[NUM_CHANNELS + 10];
	outputbuffer->c12 = FloatBuffer[NUM_CHANNELS + 11];
	outputbuffer->c0 = FloatBuffer[NUM_CHANNELS + 12];
	outputbuffer->logE = FloatBuffer[NUM_CHANNELS + 13];	
  
}

// Finalize
void fe_finalize() {
  /*----------------*/
  /* Memory release */
  /*----------------*/
  free(CircFloatBuffer);
  free(pDCTMatrix);
  ReleaseFFTWindows(&FirstWindow);
}

