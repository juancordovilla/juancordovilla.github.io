//coderembed.c (Coder embed based on ETSI ES-201-108) (Part of DSR-RT. Granada Universty)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "coderembed.h"
#include "golay.h"
#include "q8.tab"


double weight_c0 = 1.0 / 1.44600573933285341e+03;
double weight_logE = 1.0 / 1.46601586442831717e+01;

/* private functions used before they are defined */
unsigned int best_centroid(float a, float b, double *table, int NumCentroids, int weighting);
void get_best_dataframe(unsigned char *index_array, HTK_DataFrame *given);


//Initialize Coder
int coder_initialize() 
{
  return 0;
}


/***************************************
*	MAIN FUNCTION OF THIS MODULE
*
* 	encode two HTK_DataFrames that are (consecutively) in the inputbuffer
* 	and put the result into the outputbuffer parameters:
* 	unsigned char *inputbuffer: make sure, that it is possible to read 2 * 14 * sizeof(float) chars from this buffer
* 	unsigned char *outputbuffer: make sure, that it is possible to write 12 chars into this buffer
* 	returns the number of outputpairs (of 12 chars each) written into the buffer (e.g. 0 or 1)
* 	or -1 on error; currently always 1 pair is written, but this might change in the future
******************************************************/
int code_two_frames(HTK_DataFrame *inputbuffer, unsigned char *outputbuffer) 
{
  
  HTK_DataFrame firstFrame, secondFrame;  
  
  
  // have two HTK_DataFrame*'s point into the inputbuffer 
  memcpy(&firstFrame.c1, &inputbuffer[0].c1, sizeof(HTK_DataFrame));
  memcpy(&secondFrame.c1, &inputbuffer[1].c1, sizeof(HTK_DataFrame)); 

  unsigned char index_array[14]; // = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
  unsigned char crc;
 
  /*Quantise the given vectors and construct the bitstream.*/
  get_best_dataframe(&index_array[0], &firstFrame);
  get_best_dataframe(&index_array[7], &secondFrame);

/* Format the frame packet stream into binary bitstream for output */
  outputbuffer[0] = (0x3f & index_array[0]);
  outputbuffer[0] |= (0xc0 & (index_array[1] << 6));
  outputbuffer[1] = (0x0f & (index_array[1] >> 2));
  outputbuffer[1] |= (0xf0 & (index_array[2] << 4));
  outputbuffer[2] = (0x03 & (index_array[2] >> 4));
  outputbuffer[2] |= (0xfc & (index_array[3] << 2));
  outputbuffer[3] = (0x3f & index_array[4]);
  outputbuffer[3] |= (0xc0 & (index_array[5] << 6));
  outputbuffer[4] =  (0x0f & (index_array[5] >> 2));
  outputbuffer[4] |= (0xf0 & (index_array[6] << 4));
  outputbuffer[5] = (0x0f & (index_array[6] >> 4));
  outputbuffer[5] |= (0xf0 & (index_array[7] << 4));
  outputbuffer[6] = (0x03 & (index_array[7] >> 4));
  outputbuffer[6] |= (0xfc & (index_array[8] << 2));
  outputbuffer[7] = (0x3f & index_array[9]);
  outputbuffer[7] |= (0xc0 & (index_array[10] << 6));
  outputbuffer[8] = (0x0f & (index_array[10] >> 2));
  outputbuffer[8] |= (0xf0 & (index_array[11] << 4));
  outputbuffer[9] = (0x03 & (index_array[11] >> 4));
  outputbuffer[9] |= (0xfc & (index_array[12] << 2));
  outputbuffer[10] = (0xff & index_array[13]);

  crc = crc_encode(outputbuffer);   /* compute the crc for the frame pair packet */

  outputbuffer[11] = (0x0f & crc);  /* stire the crc in the outputbuffer */

  return 1;
}


void get_best_dataframe(unsigned char *index_array, HTK_DataFrame *given)
{
  index_array[0]   = best_centroid(given->c1,  given->c2,   &quantiser8kHz_0_1[0][0],   64, FALSE);
  index_array[1]   = best_centroid(given->c3,  given->c4,   &quantiser8kHz_2_3[0][0],   64, FALSE);
  index_array[2]   = best_centroid(given->c5,  given->c6,   &quantiser8kHz_4_5[0][0],   64, FALSE);
  index_array[3]   = best_centroid(given->c7,  given->c8,   &quantiser8kHz_6_7[0][0],   64, FALSE);
  index_array[4]   = best_centroid(given->c9,  given->c10,  &quantiser8kHz_8_9[0][0],   64, FALSE);
  index_array[5]   = best_centroid(given->c11, given->c12,  &quantiser8kHz_10_11[0][0],   64, FALSE);
  index_array[6]   = best_centroid(given->c0,  given->logE, &quantiser8kHz_12_13[0][0],   256, TRUE);
  return;
}


unsigned int best_centroid(float a, float b, double *table, int NumCentroids, int weighting) {
  /*Find the best centroid from a given quantiser table, using Euclidian distance*/
  /*or for logE and c0 weighted distance from the given vectors a and b.*/

  /*Apply index addressing for table, since the first dimension (NumCentroids) is*/
  /*either 256 or 64. Address is table[i][j] = *(table + i*2 + j)*/
  int i;
  
  unsigned int BestIndex = 0;
  double BestDistance;
  double Distance;

  if (weighting==FALSE) {/*Coefs c1 to c12*/
    BestDistance = (double) ((a - *(table + 0*2 + 0 ) )*(a - *(table + 0*2 + 0 )) 
                            + (b - *(table + 0*2 + 1 ))*(b - *(table + 0*2 + 1 )));
    for (i=1; i<NumCentroids; i++) {
      Distance = (double) ((a - *(table + i*2 + 0 ))*(a - *(table + i*2 + 0 ))
                          + (b - *(table + i*2 + 1 ))*(b - *(table + i*2 + 1 )));
      if (Distance < BestDistance) {
        BestDistance = Distance;
        BestIndex = i;
      }
    }
  }
  else { /*Must be c0 and logE*/
    BestDistance = (double) ((a - *(table + 0*2 + 0 ))*(a - *(table + 0*2 + 0 )) * weight_c0 
                            + (b - *(table + 0*2 + 1 ))*(b - *(table + 0*2 + 1 )) * weight_logE);
    for (i=1; i<NumCentroids; i++) {
      Distance = (double) ((a - *(table + i*2 + 0 ))*(a - *(table + i*2 + 0 )) * weight_c0
                          + (b - *(table + i*2 + 1 ))*(b - *(table + i*2 + 1 )) * weight_logE);
      if (Distance < BestDistance) {
        BestDistance = Distance;
        BestIndex = i;
      }
    }
  }
  return BestIndex;
}

//Coder finalize
int coder_finalize() 
{
  return 0;
}


