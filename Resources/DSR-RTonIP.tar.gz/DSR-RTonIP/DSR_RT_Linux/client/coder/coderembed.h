//
#ifndef TRUE
#define TRUE (1==1)
#define FALSE !TRUE
#endif

typedef struct HTK_DataFrame{
                          float c1;
                          float c2;
                          float c3;
                          float c4;
                          float c5;
                          float c6;
                          float c7;
                          float c8;
                          float c9;
                          float c10;
                          float c11;
                          float c12;
                          float c0;
                          float logE;
                          }HTK_DataFrame;


//
int coder_initialize();
int code_two_frames(HTK_DataFrame *inputbuffer, unsigned char *outputbuffer);
int coder_finalize();
