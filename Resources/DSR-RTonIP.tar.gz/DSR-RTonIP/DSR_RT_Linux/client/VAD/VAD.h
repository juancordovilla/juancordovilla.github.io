//
void InitiaRecognVAD ();
int VAD(HTK_DataFrame  *framebuffer, int Numframes, HTK_DataFrame  *framebufferToSend);
void FinalizeRecognVAD ();
