//common.c (common function of client & server) (Part of DSR-RT. Granada Universty)

#include <stdio.h>
#include <sys/time.h> //for timeval

//External variable
unsigned char COMPRESSEDTOTALSILENT[12]={0x52 ,0x28 ,0xca ,0x61 ,0xf1 ,0x2f ,0x85 ,0xa2 ,0x1c ,0x16 ,0xff ,0xd};

//To print voice�s intensity
void PrintVoice (int intensity)
{
	if (intensity < 5)
		fprintf(stderr,"0....*                         \r*");		
	if (intensity==5)
		fprintf(stderr,"0....5*                        \r*");
	if (intensity==6)
		fprintf(stderr,"0....5.*                       \r*");
	if (intensity==7)
		fprintf(stderr,"0....5..*                      \r*");
	if (intensity==8)
		fprintf(stderr,"0....5...*                     \r*");
	if (intensity==9)
		fprintf(stderr,"0....5....*                    \r");
	if (intensity==10)
		fprintf(stderr,"0....5....10*                  \r");
	if (intensity==11)
		fprintf(stderr,"0....5....10.*                 \r");
	if (intensity==12)
		fprintf(stderr,"0....5....10..*                \r");
	if (intensity==13)
		fprintf(stderr,"0....5....10...*               \r");
	if (intensity==14)
		fprintf(stderr,"0....5....10....*              \r");
	if (intensity==15)
		fprintf(stderr,"0....5....10....15*            \r");
	if (intensity==16)
		fprintf(stderr,"0....5....10....15.*           \r");
	if (intensity==17)
		fprintf(stderr,"0....5....10....15..*          \r");
	if (intensity==18)
		fprintf(stderr,"0....5....10....15...*         \r");
	if (intensity==19)
		fprintf(stderr,"0....5....10....15....*        \r");
	if (intensity==20)
		fprintf(stderr,"0....5....10....15....20*      \r");
	if (intensity==21)
		fprintf(stderr,"0....5....10....15....20.*     \r");
	if (intensity==22)
		fprintf(stderr,"0....5....10....15....20..*    \r");
	if (intensity==23)
		fprintf(stderr,"0....5....10....15....20...*   \r");
	if (intensity==24)
		fprintf(stderr,"0....5....10....15....20....*  \r");
	if (intensity==25)
		fprintf(stderr,"0....5....10....15....20....25*\r");	
}

//Substract two time�s mark 
long restaTiempo(struct timeval *tfin, struct timeval *tini){
   
	long tfinus = tfin->tv_sec*1000000+ tfin->tv_usec;
	long tinius = tini->tv_sec*1000000+ tini->tv_usec;
	
	return (tfinus-tinius);
}

//Time statistic
void TimeStatistic (struct timeval *tini, struct timeval *tfin, long imax)
{
	long i;
	long deltaus, max=0, min=1000000, sum=0;	
	
	for(i=1; i<imax; i++)
	{
		deltaus = restaTiempo(&tfin[i],&tini[i]);
		
		printf("%ld ", deltaus);
		if(deltaus<min){min=deltaus;}
		if(deltaus>max){max=deltaus;}
		sum+=deltaus;
	}
	
	printf("\nMin: %ld, Max: %ld, Ave: %ld\n\n", min, max, (sum/imax));	
	
}


