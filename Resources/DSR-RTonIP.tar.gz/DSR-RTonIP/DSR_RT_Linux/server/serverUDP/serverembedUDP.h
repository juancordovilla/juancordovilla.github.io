//RECEIVEREMBEDUDP.h

int InitiaReceiverUDP ();
int BlockingModeUDP (int mode);
int ReceiverUDP (rtpPacket *PacketOut);
int TerminReceiverUDP();
