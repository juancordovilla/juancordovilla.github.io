//serverembedUDP.c (Server embed UDP)  (Part of DSR-RT. Granada Universty)

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h> //For ioctl() Non Blocking mode
#include <netinet/in.h> 
#include <arpa/inet.h>
#include <unistd.h> //For close(sock)
#include "../../common.h"  //For size of rtpPacket
#include "../statistic/statistic.h"	//For struct info_pair_frame

//Comunication variables and File
int sock;
struct sockaddr_in client, server;
unsigned int ClientAdrrSize = sizeof(client);  

//Receiver variables
rtpPacket buffWait[BUFFER_SIZE]; //Where the packets�ll wait. buffer[0] is the oldest packet  
rtpPacket PacketToProcess[BUFFER_SIZE]; //The packets from here will be processed 
unsigned int expected_number = 0; 
rtpPacket currentPacket;
rtpPacket FakePacket={0, 1, 0, 0, 0, {0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x10}}; //the first 1 indicate that is Fake
rtpPacket InitPacket={0, 0, 0, 0, 0, {0x52 ,0x28 ,0xca ,0x61 ,0xf1 ,0x2f ,0x85 ,0xa2 ,0x1c ,0x16 ,0xff ,0xd}}; //is a no Total Silent Packet (logE=1.0)



extern info_framePairs ExtInfoFramePair[SIZEFRAMEPAIRS];  //see statistic definition

void copyrtpPacket(rtpPacket *Packetdest, rtpPacket *Packetorig)
{
	memcpy(&Packetdest->flags, &Packetorig->flags, 1);
	memcpy(&Packetdest->payload_type, &Packetorig->payload_type, 1);
	memcpy(&Packetdest->sequence_number, &Packetorig->sequence_number, 4);
	memcpy(&Packetdest->timestamp, &Packetorig->timestamp, 4);
	memcpy(&Packetdest->synchronization_source, &Packetorig->synchronization_source, 4);
	memcpy(&Packetdest->payload[0], &Packetorig->payload[0], PAYLOAD_SIZE);	
	
	//To see the Packets arrived
	/*fprintf(stderr,"%x %x %x ",Packetdest->payload[0], Packetdest->payload[1], Packetdest->payload[2]);
	fprintf(stderr,"%x %x %x ",Packetdest->payload[3], Packetdest->payload[4], Packetdest->payload[5]);
	fprintf(stderr,"%x %x %x ",Packetdest->payload[6], Packetdest->payload[7], Packetdest->payload[8]);
	fprintf(stderr,"%x %x %x\n",Packetdest->payload[9], Packetdest->payload[10], Packetdest->payload[11]);
	fflush(stderr);*/
}

//Initia Receive.  Communication mode and rtp correction
int InitiaReceiverUDP ()
{
	int j;
	
	//Fill buffWait at the begin	
	for (j=0; j<BUFFER_SIZE; j++)
		copyrtpPacket(&buffWait[j], & InitPacket);		
		
	
	// Create Socket
	sock = socket(AF_INET,SOCK_DGRAM,0);
	if (sock < 0) {perror("sock"); exit(1);} 	
	
	//BlockingModeUDP (1);
	
	//Asign our own(server) address 	
    server.sin_family = AF_INET;//Domain Internet
    server.sin_port = htons(atoi(UDP_PORT)); //Port
    server.sin_addr.s_addr = htonl(INADDR_ANY); //any IP  in this host
	
	//Connect server to socket
	if( bind(sock,(struct sockaddr*)&server, sizeof(server)) < 0) {perror("bind"); exit(1);} 
	fprintf(stderr,"\nChild Server on listening UDP port: %s\n",UDP_PORT);
	
	return 1;
}

//Blocking mode UDP (mode 1: Non blocking mode, mode 0: Blocking mode)
int BlockingModeUDP (int mode)
{
	//Blocking mode 
	ioctl(sock, FIONBIO, (char *) & mode);
	return 1;
}


//Shift one time all buffer
//Put pay buffWait[0].payload in PayloadsToProcess[position][ ]. buffWait[BUFFER_SIZE-1] has the recentest packet 
void shiftbuffer(rtpPacket *Packet, int position)
{
	int j;
	
	copyrtpPacket(&PacketToProcess[position], &buffWait[0]);
	
	for (j=0; j<BUFFER_SIZE-1; j++)
		copyrtpPacket(&buffWait[j], &buffWait[j+1]); 
		
		
	copyrtpPacket(&buffWait[BUFFER_SIZE-1], Packet); 	
}	

//Put the packet in the  buffWait respect the first packet different from -1	
void PlacePacket (rtpPacket *Packet)
{
	int i, position;
	//Find the first different from -1 to have a reference point	
	for(i=0; i<BUFFER_SIZE; i++)
	{	
		if(buffWait[i].payload_type!=1)
			break;
	}
	
	//Write in the correct position
	position=i+(Packet->sequence_number - buffWait[i].sequence_number);	
	if ((position>=0)&&(position<BUFFER_SIZE))
	{
		fprintf(stderr,"\nRTP: Writing old packet %d", Packet->sequence_number);
		copyrtpPacket(&buffWait[position], Packet);		
	}
}


/***************************************
*	MAIN FUNCTION OF THIS MODULE
*
*	Receiver UDP packets with algorithm rtp ordenation
*	Return the n� of payload to process
********************************/
int ReceiverUDP (rtpPacket *PacketOut)
{
	int i, shift=0;
		
	if (recvfrom(sock, &currentPacket, sizeof(currentPacket),0,(struct sockaddr*) &client, &ClientAdrrSize)>= 0) 
	{
		ExtInfoFramePair[currentPacket.sequence_number].arrived=1;	//for statistic	
		//Received the expected packet or another with bigger number 
		if (currentPacket.sequence_number >= expected_number)
		{
			shift=currentPacket.sequence_number+1-expected_number;			
			if (shift>BUFFER_SIZE)
				shift=BUFFER_SIZE;	//because a big shift is the same that this shift
			for (i=0; i<shift-1; i++)
			{
				//If the packeted hasn�t arrived put a FAKE packet (Maybe later might arrive) 
				FakePacket.sequence_number = (currentPacket.sequence_number-shift)+i+1;
				fprintf(stderr,"\nRTP: Writing fake packet %d", FakePacket.sequence_number);
				shiftbuffer(&FakePacket, i);					
			}
			
			shiftbuffer(&currentPacket, i);	
			
			//We�ll expect the follow number to the recently received
			expected_number=currentPacket.sequence_number+1;
			//We return the n� of packet ready to be processeds
			for(i=0; i<shift; i++)
				copyrtpPacket(&PacketOut[i], &PacketToProcess[i]);					
			
			return shift;
		}			
		//Received older packet than the  expected
		else
		{
			fprintf(stderr,"\nRTP: Placeing old packet %d", currentPacket.sequence_number);
			PlacePacket(&currentPacket);
			return -1;
		} 
		
		
	}
	//No received
	else	return -1;	
}


//Termination Receive
int TerminReceiverUDP()
{
	//Close socket
	close(sock);	
	return 1;	
}

