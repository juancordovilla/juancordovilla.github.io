//fatherTCP.h

int InitiaServerTCP ();
int BlockingMode (int mode);
int ReceiveTCP (char *cad);
int SenderTCP(char *cad);
int FinalizeTCP ();
int SendTCPSpeechFile();
