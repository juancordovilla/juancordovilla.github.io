/******************************************************************************
*
*      ETSI STQ WI007 DSR Front-End Compression Algorithm
*      C-language software implementation 
*      Version 1.1.3   May, 2003
*
*
******************************************************************************/
/*---------------------------------------------------------------------------
 *
 * FILE NAME: golay.c
 * PURPOSE:   Golay and CRC routines for split VQ Distributed Speech Recognition
 *            Compression  coder and decoder.
 * INPUT:     
 * OUTPUT:    
 *---------------------------------------------------------------------------*/


#ifndef TRUE
  #define TRUE  (1==1)
  #define FALSE !TRUE
#endif

#define TESTING FALSE

#define DATA_LEN 16


unsigned short golay_encode(unsigned short data)
{
				 
  unsigned short g_matrix[16] = {0x808b,
                                 0xc0ce,
                                 0xe0ed,
                                 0x7077,
                                 0xb8b0,
                                 0x5c58,
                                 0x2e2c,
                                 0x1716,
                                 0x8b01,
                                 0x4581,
                                 0x22c1,
                                 0x1161,
				 0x08b1,
				 0x0459,
				 0x022d,
				 0x0117};
				 
  int bit;
  unsigned short mask;
  unsigned short crc=0x0;
  
  for (bit=0,mask=0x1; bit<16; bit++,mask<<=1)
    if (mask & data)
      crc ^= g_matrix[bit];
      
#if(TESTING)
  printf("header data = %03x\n",data);
#endif    

  return crc;
}





int golay_errors(unsigned short *data, unsigned short *crc)
{
  unsigned short golay_encode(unsigned short data);

  unsigned short data_copy,
                 crc_copy;
  
  int i, j, k;

  
  /*everything is ok*/
  if ((*crc) == golay_encode(*data)) return FALSE;



  /*May be 1 bit error in data or crc */


  for(i=0; i<DATA_LEN; i++)
  {
    data_copy = (0x1 << i) ^ (*data);
    
    if((*crc) == golay_encode(data_copy))
    {
      *data = data_copy;
      return FALSE;
    }
  }


  for(i=0; i<DATA_LEN; i++)
  {
    crc_copy = (0x1 << i) ^ (*crc);
    
    if(crc_copy == golay_encode(*data))
    {
      *crc = crc_copy;
      return FALSE;
    }
  }


  /*May be 2 bit errors in either crc/data or both*/
  /*1st check data for 2 errors, 2nd check crc for 2 errors, 3rd, check both for 1 error*/

  for(i=0; i<(DATA_LEN-1); i++)
    for(j=(i+1); j<DATA_LEN; j++)
    {
      data_copy = ((0x1 << i) | (0x1 << j)) ^ (*data);

      if((*crc) == golay_encode(data_copy))
      {
	*data = data_copy;
	return FALSE;
      }
    }



  for(i=0; i<(DATA_LEN-1); i++)
    for(j=(i+1); j<DATA_LEN; j++)
    {
      crc_copy = ((0x1 << i) | (0x1 << j)) ^ (*crc);

      if(crc_copy == golay_encode(*data))
      {
        *crc = crc_copy;
	return FALSE;
      }
    }


  for(i=0; i<DATA_LEN; i++)
  {

    data_copy = (0x1 << i) ^ (*data);

    for(j=0; j<DATA_LEN; j++)
    {
      crc_copy = (0x1 << j) ^ (*crc);

      if(crc_copy == golay_encode(data_copy))
      {
        *crc = crc_copy;
	*data = data_copy;
	return FALSE;
      }
    }
  }



  /*Maybe 3 bit errors*/

  /*Maybe 3 in data or 3 in crc, or 2 in data 1 in crc, or 1 in data 2 in crc*/
  
  for(i=0; i<(DATA_LEN-2); i++)
    for(j=(i+1); j<(DATA_LEN-1); j++)
      for(k=(j+1); k<DATA_LEN; k++)
      {
	data_copy = ((0x1 << i) | (0x1 << j) | (0x1 << k)) ^ (*data);

	if((*crc) == golay_encode(data_copy))
	{
	  *data = data_copy;
	  return FALSE;
	}
      }


  for(i=0; i<(DATA_LEN-2); i++)
    for(j=(i+1); j<(DATA_LEN-1); j++)
      for(k=(j+1); k<DATA_LEN; k++)
      {
	crc_copy = ((0x1 << i) | (0x1 << j) | (0x1 << k)) ^ (*crc);

	if(crc_copy == golay_encode(*data))
	{
          *crc = crc_copy;
	  return FALSE;
	}
      }





  for(i=0; i<(DATA_LEN-1); i++)
    for(j=(i+1); j<DATA_LEN; j++)
    {
        data_copy = ((0x1 << i) | (0x1 << j)) ^ (*data);
      
	for(k=0; k<DATA_LEN; k++)
        {
          crc_copy = (0x1 << k) ^ (*crc);

          if(crc_copy == golay_encode(data_copy))
	  {
            *crc = crc_copy;
	    *data = data_copy;
	    return FALSE;
	  }
        }
    }




  for(i=0; i<(DATA_LEN-1); i++)
    for(j=(i+1); j<DATA_LEN; j++)
    {
        crc_copy = ((0x1 << i) | (0x1 << j)) ^ (*crc);
      
	for(k=0; k<DATA_LEN; k++)
        {
          data_copy = (0x1 << k) ^ (*data);

          if(crc_copy == golay_encode(data_copy))
	  {
            *crc = crc_copy;
	    *data = data_copy;
	    return FALSE;
	  }
        }
    }








#if(TESTING)
  printf("Can't find error !\n");
#endif

  return TRUE;
}







unsigned char crc_encode(unsigned char data[])
{
  static int first = TRUE;
  static unsigned char crc4_lut[16];

  
  int i,j;
/*
 *   unsigned char mask = 0x8;   equivalent to 1 + X**4 
 */
  unsigned char mask = 0xc;  /* equivalent to 1 + x + X**4 */


  unsigned char crc;
  unsigned char nibble;


  
  if (first)
  {
    for (i=0; i<16; i++)
    {
      crc = i;
      for (j=0; j<4; j++)
        crc = (crc & 0x1) ? ((crc >> 1) ^ mask) : (crc >> 1);
      crc4_lut[i] = crc;
    }
      
    first = FALSE;
  }
  
  #if(TESTING)
    for (i=0; i<11; i++)
      printf("data[%d] = %02x\n",i,data[i]);
  #endif

  crc = 0;  
  for (i=0; i<22; i++)
  {
    nibble = (i % 2 == 0) ? (0xf & data[i / 2]) : ((0xf0 & data[i / 2]) >> 4);
    
    #if(TESTING)
      printf("nibble[%d] = %01x\n",i,nibble);
    #endif
      
    crc = crc4_lut[crc ^ nibble];

    #if(TESTING)
      printf("crc after nibble[%d] = %01x\n",i,crc);
    #endif
  }
  
  return crc;
}



int crc_errors(unsigned char data[], unsigned char crc)
{
  unsigned char crc_encode(unsigned char data[]);
  
  if (crc == crc_encode(data)) return FALSE;

  return TRUE;
}

