// DEFINITION
/*Thresholds.*/
/* Last speech frame detection for frame detected with bad crc */
#define ZEROS_THRESHOLD 5 
/*if in a crc errored frame, if ZEROS_THRESHOLD out of 7 are zero, assume that this is the lastframe + 1*/

/* Search for errored frames missed by CRC */
#define ERRORS_THRESHOLD 2 
/* When looking at thresholds if ERRORS_THRESHOLD or greater are over the thres then decide it is in error. */

#define DETECTION_THRES_COEF 3.0
/*in relation to s.d.'s of differences from training data*/

#ifndef TRUE
#define TRUE (1==1)
#define FALSE !TRUE
#endif

#define ONE_FRAME 0
#define TWO_FRAMES !ONE_FRAME

/*Structures for HTK Files*/

typedef struct HTK_DataFrame{
                          float c1;
                          float c2;
                          float c3;
                          float c4;
                          float c5;
                          float c6;
                          float c7;
                          float c8;
                          float c9;
                          float c10;
                          float c11;
                          float c12;
                          float c0;
                          float logE;
                          }HTK_DataFrame;

typedef struct HTK_Header{
                          unsigned int nSamples;
                          unsigned int sampPeriod;
                          unsigned short int sampSize;
                          unsigned short int parmKind;
                          }HTK_Header;


typedef struct dframe{
  unsigned char a[7];
  unsigned char b[7];
  unsigned char crc;
}dframe;




//ETSI funtion
void init_thresholds(void);
int process_two_frames(dframe **BufferedDFrames, dframe *CurrentDFrame, dframe *LastGoodDFrame, dframe *PreviousDFrame,  
                        int *dataframes_buffered, int endFrames, int buffering_data_mode);
void add_to_buffer(dframe **BufferedData, dframe *ToBuffer, int buffered_count);
int threshold_error(dframe DataFrame);
void dequantise_dataframe(HTK_DataFrame *result, unsigned char given_index[7]);
void error_correct_and_write(unsigned char Left[7], unsigned char Right[7], dframe *BufferedData, int count);
int sync_error(unsigned char *given_sync, unsigned short int sync);
void print_htk_coefs(HTK_DataFrame given);
void write_two_data_frames(dframe given, int numFrames);

//Our function
void decoder_initialize();
int decode_two_frames(rtpPacket *inputbuffer, unsigned char **outputbuffer);
void decoder_finalize();
int convert_pair(unsigned char *two_data_frames, dframe *DataFrame);
void write_htk_coefs(HTK_DataFrame *given);




