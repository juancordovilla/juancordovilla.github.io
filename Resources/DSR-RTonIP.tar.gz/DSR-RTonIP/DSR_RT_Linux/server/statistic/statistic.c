//statistic.c (Statistic of arrived & CRC UDP-RTP packet)  (Part of DSR-RT. Granada Universty)

#include <stdio.h>
#include "statistic.h"	//For struct info_frame

info_framePairs ExtInfoFramePair[SIZEFRAMEPAIRS];  //External variable where decoder and receiverUDP write 
FILE *fp_statistic=NULL; 

int num_not_arrived=0, num_CRC_error=0, total_sended;

//Initia Statistic File
void IniPrintStatisticFich()
{
	fp_statistic = fopen("FichStat.txt","w");
	num_not_arrived=0; num_CRC_error=0;
}	


/***************************************
*	MAIN FUNCTION OF THIS MODULE
*
*	Print Statistic of arrive and CRC_error of a packet UDP-RTP
***************************************/
void PrintStatisticFich (char *recognition_result, int nini, int nfini)
{
	int i;
	
	total_sended=nfini;
	
	for(i=nini; i<nfini; i++)
	{
		fprintf(fp_statistic, "\n%d:", i); 	
		
		if(ExtInfoFramePair[i].CRC_error==1)
		{
			fprintf(fp_statistic, "\tCRC_ERROR "); 
			num_CRC_error++;
		}
		else
		{
			fprintf(fp_statistic, "            ");
		}
		
		if(ExtInfoFramePair[i].arrived==1)
		{
			fprintf(fp_statistic, " 		    "); 
		}
		else
		{
			fprintf(fp_statistic, "\tNOT ARRIVED"); 
			num_not_arrived++;
		}
	}
	
	fprintf(fp_statistic, "\n*******************************************************");
	fprintf(fp_statistic, "\n\t\t%s", recognition_result);
	fprintf(fp_statistic, "\n*******************************************************");
	fflush(fp_statistic);
}

//Finalize file statistic
void FinPrintStatisticFich()
{
	fprintf(fp_statistic, "\n\nNumber_not_arrived:%d, Num_CRC_error:%d, Total_sended:%d", 
			num_not_arrived, num_CRC_error, total_sended);
	fprintf(fp_statistic, "\nPercentage_not_arrived:%5.1f, Percentage_CRC_error:%5.1f  ", 
			100*((double)num_not_arrived)/total_sended, 100*((double)num_CRC_error)/total_sended);	
	
	fclose(fp_statistic);
	
}
