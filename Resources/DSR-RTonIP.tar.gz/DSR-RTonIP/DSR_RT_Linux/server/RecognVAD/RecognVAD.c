//RecognVAD.c (Recognition & Voice Activity Detector) (Part of DSR-RT. Granada Universty)

#include <stdio.h>
#include <string.h>	//for memcpy
#include "../../common.h"  //For size of PayloadBuffer, for  SIGSERVER
#include "../decoder/decoderembed.h"	// for the HTK_ DataFrame of decoder	
#include "recogembed.h"

#define TOTALSILENCE 7.0	//when a coeff (LogE) pass this limit  finish the word
#define COEFF logE //coeff to compare with LIMIT
#define RISING 1
#define DOWN 0

int status=DOWN;

//Initia now only the htkfile 
void InitiaRecognVAD ()
{
	SetRecognizer();
	status=DOWN;	
}


/***************************************
*	MAIN FUNCTION OF THIS MODULE
*
*	Mades  Recognition & VAD. Return 1: if a recognition has been done.  
***************************************/
int RecognVAD(unsigned char *framebuffer, int Numframes, char **result)
{	
	int j;
	HTK_DataFrame frame;
	
	for (j = 0; j < Numframes; j++) 
	{
		memcpy(&frame, &framebuffer[j * sizeof(HTK_DataFrame)],sizeof(HTK_DataFrame));		
				
		switch(status) //normally see status of the log E  ( buff[QUEUELENGTH-1].COEFF )	
		{	
			case DOWN: //There isn�t voice�s wave
				if (frame.COEFF > TOTALSILENCE)
				{
					recognizer_initialize(&frame); //INITIA HVITE 					
					status=RISING;
				}
				else{/*Reject data*/}					
				break;			
			
			case RISING: //There is voice�s wave and when there isn�t, obtain result
				if (frame.COEFF < TOTALSILENCE)
				{
					recognizer_finalize(result); //FINALIZE HVITE	
					status=DOWN;
					return 1;
				}
				else { recognize(&frame); }					
				break;			
		}
	}
	return 0;	//Non recognition done
}

void FinalizeRecognVAD ()
{
	CloseRecogn();
}
