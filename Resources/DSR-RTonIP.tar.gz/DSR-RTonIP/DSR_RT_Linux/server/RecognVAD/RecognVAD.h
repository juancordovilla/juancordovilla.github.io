//
void InitiaRecognVAD ();
int RecognVAD(unsigned char *framebuffer, int Numframes, char **result);
void FinalizeRecognVAD ();
