function MI=AroundLineMStrip(M,p,hl)
%Around Line Strip Matrix Strip (Band)
%p: center positions (0 means not band)
[nr nc]=size(M);  MI=zeros(nr,nc); n=1:nc;
for i=0:hl
    ps=min(p+i,nr); ps=max(ps,1);  ind = sub2ind([nr nc], ps, n);    MI(ind)=1;
    ps=min(p-i,nr); ps=max(ps,1);  ind = sub2ind([nr nc], ps, n);    MI(ind)=1;
end
MI(:,p==0)=0;