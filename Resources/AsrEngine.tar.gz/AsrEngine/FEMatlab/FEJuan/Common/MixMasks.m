function mom=MixMasks(om,m,px)
%
v=px>1; 
om=om+0; %convert logic2num
mom=om; mom(:,v)=m(:,v); 


