function [labma]=MaxLinSel(lab,Sl,shl,kind,TG)
%Maximum Lines Selection using kind 
%kind: 'E' (energy), 'T' (total energy)


hm=shl; %half mode line (related to bwareopen)

[FL, nf]=size(TG);
nl=length(Sl.xma);
LinE=MLines(lab,-1,Sl,TG,kind); 
Labl=MLines(lab,-1,Sl,TG,'L');
[v,rp]=max(LinE);
ind=sub2ind([FL nf],rp,1:nf); lma=Labl(ind); 

lma=ModeF(lma,hm);

i=ismember(lab,lma); labma=lab(i); 


% EMal=MLines(labma,-1,Sl,TG,'T');
% subplot(311), imagesc(TG), axis xy
% subplot(312), imagesc(LinE), axis xy
% subplot(313), imagesc(EMal), axis xy
% pause

