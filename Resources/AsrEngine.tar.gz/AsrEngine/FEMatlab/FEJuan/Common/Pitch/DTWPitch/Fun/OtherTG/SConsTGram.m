function CG=SConsCGram(y,S)
%Spectrum Consensus ChromaGram


%S.N=length(y); S.T=55; y=Signals('Rep',-1,S);


[My, nf]=Segmx(y,S.FL,S.FS);
[FL, nf]=size(My);
CG=zeros(S.ph,nf);


for n=1:nf   
   n
   CG(:,n)=SCons(My(:,n),S); 
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function I=SCons(y,S)
%
L=length(y);
NFT=L;
y=100*(y/max(y));


ym=repmat(y',[L 1]);
yr=repmat(y,[1 L]);
d=round(abs(ym-yr)); %row i has: sample i compared with all y signal
ma=round(max(d(:)));
rm=[1:-1/10:0.7 zeros(1,ma)]; 
yc=rm(d+1); yc=yc'; %column j has sample j compared with all y signal (is 
%pulse periodic T signal)
Ym=abs(fft(yc,NFT));


% %Product (does not work)
% Y=nthroot(prod(Ym),L);
% I=f2p(Y,NFT,S.pl,S.ph); 


%Ifft
Y=ifft(log(Ym)); 
i=isinf(Y)|isnan(Y); Y(i)=0;
Y=nthroot(sum(Y,2),3); 
I=zeros(S.ph,1);
I(S.pl:S.ph)=Y(S.pl:S.ph);


function Yp=f2p(Yf,NFT,pl,ph)
%Freq 2 Pitch
Yp=zeros(ph,1);
for p=pl:ph
    bl=round(NFT/(p+1));
    bh=round(NFT/(p-1));
    Yp(p)=mean(Yf(bl:bh));
end
    








