function [BWr,Etg]=BWRegion(TG,WL,flf,pl)
%The extreme are cut to avoid pitch

hs=round(WL/5); %half smooth win energy
hmi=round(WL/2); %half min win energy
mia=round(2*WL/5); %min area 

[FL nf]=size(TG);
Etg=sqrt(var(TG(pl:end,:)))+mean(TG(pl:end,:)); %when a pitch, Ac vibrates (+-) and the var increases
Eb=MinSt(Etg,hs,hmi);




EbM=repmat(Eb,[FL 1]); 
BWr=TG>EbM; BWr(:,1:flf)=0; BWr(:,nf-flf:end)=0;
BWr=bwareaopen(BWr,mia);

% subplot(311), imagesc(TG), axis xy
% subplot(312), imagesc(BWr), axis xy
% subplot(313), plot(Etg), hold on, plot(Eb,'r'),xlim([1 length(Eb)]), hold off
% pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

















