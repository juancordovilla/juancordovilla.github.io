function CG=YinCGram(y,S)
%Yin ChromaGram

R = yin_speech(y,struct('sr',S.FSamp,'hop',S.FS)); 

CG=R.dd((0:S.ph)+1,:);

CG=min(CG,2);
ma=max(CG(:)); mi=min(CG(:)); CG=(CG-mi)/(ma-mi); 
%i=CG>0.5; CG(i)=1;
CG(1:S.pl,:)=1;

%CG=CG-1;
CG=-1*CG+1;





