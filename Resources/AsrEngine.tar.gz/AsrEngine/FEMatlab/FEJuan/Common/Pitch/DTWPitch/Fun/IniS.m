function S=IniS(nl,nf)
%Initialize Line Structure
S.x=zeros(nl,nf); S.py=zeros(nl,nf); S.EI=zeros(nl,nf);
S.xmi=zeros(nl,1); S.xma=zeros(nl,1); S.pymi=zeros(nl,1); S.pyma=zeros(nl,1); 
S.lab=zeros(nl,1); S.l=zeros(nl,1); S.E=zeros(nl,1);