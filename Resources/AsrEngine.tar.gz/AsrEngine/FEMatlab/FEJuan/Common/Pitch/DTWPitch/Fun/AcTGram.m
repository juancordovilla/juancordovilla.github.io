function [CG,CGA]=AcTGram(y,P)
%AutoCorr ChromaGram

[My, nf]=Segmx(y,P.FL,P.FS);


[Rb, Ru, Rosab, Rosau] =M2AC(My);

CG=Rosau(1:P.MaPitL+1,:); 

s=sign(CG); CG=s.*sqrt(abs(CG));

CG=TGTransf(CG,'norm',-1);

CGA=CG;
CG(1:P.MiPitL,:)=0;


 
