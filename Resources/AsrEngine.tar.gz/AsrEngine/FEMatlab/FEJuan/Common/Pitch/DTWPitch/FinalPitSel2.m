function pit=FinalPitSel2(Sdtw,Smal,pym,Etg,fmai,vf,shl,TG,TGA)
%

%
labmean=LabArPM(Smal,pym,fmai); %labs around mean pitch
[labmax]=MaxLinSel(labmean,Smal,shl,'E',TG); %with equal E line chose that which has min pitch
TGlmax=MLines(-1,labmax,Smal,TG,'E'); 
[v p]=max(TGlmax); p(p==1)=0;
MI=AroundLineMStrip(TG,p,7);
TGRev=TG.*MI;
[v p]=max(TGRev); 
pit=p-1;

%
% [nr nf]=size(TG);
% TGlmal=MLines(-1,Smal.lab,Smal,TG,'E');
% TGlmean=MLines(-1,labmean,Smal,TG,'E');  
% subplot(511), imagesc(TG), axis xy
% subplot(512), imagesc(TGlmal), axis xy
% subplot(513), imagesc(TGlmax), axis xy
% subplot(514), imagesc(TGRev), axis xy
% subplot(515), plot(pit), xlim([1 nf])
% pause



