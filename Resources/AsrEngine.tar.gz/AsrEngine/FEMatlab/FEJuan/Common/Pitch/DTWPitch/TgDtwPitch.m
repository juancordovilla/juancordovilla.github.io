function [py, px]=TgDtwPitch(y,x,P)
%


P.pl=P.MiPitL; P.ph=P.MaPitL;

[py,S]=TPitch(x,P); 
[px,S]=TPitch(x,P);

%To Plot
BWrl=0.5*(-MLines(S.Sdtw.lab,1,S.Sdtw,TG,'1'))+0.5*BWr; i=BWrl==0.5; BWrl(i)=0.2;
TGmal=MLines(S.Smal.lab,-1,S.Smal,TG,'E');  

%PlotPresFig1(TGy,BWrly,TGmaly,py,px);





