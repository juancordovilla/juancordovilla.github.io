function xs=Smooth(x,hl)
%hl: half window length
ns=length(x);
xs=x;
for i=1+hl:ns-hl; xs(i)=mean(x(i-hl:i+hl)); end

