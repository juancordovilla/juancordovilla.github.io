function [CG,CG4]=SiftTGram(y,S)
%Sifting ToneGram (for D=0 it works OK)

[My, nf]=Segmx(y,S.FL,S.FS);
CG=zeros(S.ph+1,nf);
D=8;
for p=S.pl:S.ph 
    CG(p+1,:)=SiftI(My,p,D); 
end
CG=TGTransf(CG,'norm',-1);
CG4=MMax(CG,4);
%s=sign(CG); CG=s.*sqrt(abs(CG));
%CG=-1*CG; 
%CG=PSamp2AFreq(CG,S.pl,S.ph,55,30);


%CG=medfilt2(CG, [3 5]);
%F = [.05 .1 .05; .1 .4 .1; .05 .1 .05]; ZC = conv2(ZN,F,'same'); %Low pass
%4Hz

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function I=SiftI(My,T,D)
%
[FL nf]=size(My);
Np=floor(FL/T)+1;
[a,b, np]=ppos(FL,T,Np,D); l=length(a);
M=repmat(1:nf,[l 1]);
A=repmat(a,[1,nf]);
B=repmat(b,[1,nf]);
I1 = sub2ind([FL nf], A, M);
I2 = sub2ind([FL nf], B, M);
I=sum(My(I1).*My(I2))/np;
s=sign(I); I=s.*sqrt(abs(I));
   
function [a,b, np]=ppos(FL,T,Np,D)
%Prod Posic (for D=0 work OK)
l=triu(true(Np)); 
a=repmat(0:Np-1,[Np,1]); a=a(l);
b=repmat((0:Np-1)',[1 Np]);  b=b(l);

l=length(a);
i=repmat(0:T-1,[l 1]);
a=repmat(a,1,T)*T+i;
b=repmat(b,1,T)*T+i;
i= a<FL & b<FL & abs(a-b)>=D;
a=a(i)+1; b=b(i)+1; np=sum(i(:));





