function CG=DifCGram(y,S)
%Diferential ChromaGram

[My, nf]=Segmx(y,S.FL,S.FS);
CG=zeros(S.ph,nf);



for p=S.pl:S.ph  
    CG(p,:)=DifI(y,p,S);      
end

CG=sqrt(CG);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function I=DifI(y,p,S)
%

b=[1 zeros(1,p-1) -1];
yf=filter(b,1,y);
[Myf, nf]=Segmx(yf,S.FL,S.FS);
I=sum(Myf.^2)/S.FL;