function CG=LPCCGram(y,S)
%LPC Chroma Gram

NFT=512; p=16;
[My, nf]=Segmx(y,S.FL,S.FS);
[a, G]=lpc(My,p); 

b=a'; b(1,:)=0; a=ones(1,nf);
Mye=MFilt(My,b,a,S.FL,S.FS,nf,p); 
D=My-Mye;


%G=repmat(G',[NFT, 1]);CG=G./abs(fft(a,NFT)); CG=20*log10(CG(1:NFT/2,:));

[Rb, Rosab,Rosau]=Mx2Rx(D); 
CG=Rosab(1:S.ph+1,:); 
CG(1:S.pl,:)=0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Myf=MFilt(My,b,a,FL,FS,nf,p)
%Matrix Filtering
Myf=zeros(FL,nf+1);
for i=2:nf+1
    zi_1=Myf(FS-p+1:FS,i-1); 
    Myf(:,i)=filter(b(:,i-1),a(:,i-1),My(:,i-1),zi_1);
end
Myf=Myf(:,2:nf+1);