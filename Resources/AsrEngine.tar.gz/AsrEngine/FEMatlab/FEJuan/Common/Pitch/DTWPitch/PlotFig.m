function PlotFig(TGy,BWrly,TGmaly,py,px)
%Paper Figure

TGmaly=GoodTGmal(TGmaly);
BWrly=GoodBWrl(BWrly);


bt=15;
subplot(411), imagesc(TGy), axis xy, title('Tonegram','FontSize', bt)
subplot(412), image(BWrly), axis xy, title('High energy regions and DTW lines','FontSize', bt)
subplot(413), imagesc(TGmaly), axis xy, title('Tonegram estimate of max lines','FontSize', bt)
subplot(414), plot(py,'ro'), hold on, plot(px), 
hold off, title('Estimated (circ.) and clean (line) pitch','FontSize', bt), xlim([1 length(py)])
ylabel('Pitch (sample)','FontSize', bt), xlabel('Time (frame)','FontSize', bt),  
sum(py)
pause





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Ao=GoodTGmal(A)
%
A=gray2ind(A);
i=A==0; A(i)=25;
Ao=A;



function Ao=GoodBWrl(A)
%
A=-A+1;
A= repmat(A,[1 1 3]);
Ao=A;