I have tried other pitch such as:

Droppo (Microsoft for A2)
Matlab Chrom (some USA person, Terry)
Ning (Ning Ma)
DTW original (of Pablo)
Praat (Boers..)
Safe (from Wei Chu, Abeer Alwan)
AFE (Advance Front End)
