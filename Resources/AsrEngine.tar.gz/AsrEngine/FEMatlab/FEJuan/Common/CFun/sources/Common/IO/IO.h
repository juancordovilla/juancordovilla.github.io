//
float* ReHtkF(int *nr, int *nc, char *fn);





//Print
void PrintfM(float *M, int nr, int nc);

