#include <stdio.h> //fopen, printf 
#include <stdlib.h> //rand, abs, system 
#include <sys/time.h> //timeval
#include <math.h> //sqrt, fabs, ceil



////////////////////////////////////////////////////////// SIMPLE OPERATORS ////////////////////////////////////////////////////////////

/*Create array of all zeros*/
void Zeros(float *x, int lx)
{
	int i;
	for(i=0; i<lx; i++)
		x[i]=0.0;

}

/*Create array of all zeros*/
void Ones(float *x, int lx)
{
	int i;
	for(i=0; i<lx; i++)
		x[i]=1.0;

}



