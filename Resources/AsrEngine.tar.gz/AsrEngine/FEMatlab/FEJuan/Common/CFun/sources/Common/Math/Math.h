//Numbers
#define M_PI        3.14159265358979323846
#define M_SQRT2     1.41421356237309504880
#define PI          M_PI
#define PIx2        6.28318530717958647692 

/*Math.h*/
void Mfft (float *Sp, float *x, float *w, int lx, int N, int log2N);
int xcorr (float *Corr, float *x1, float *x2, int lx, char kind);
void rxosa (float *ACorr, float *x, int tam, char kind);
int MDft (float *M, float *x, int ndft, int lx);
void PSD (float *Sp, float *x, float *w, int Nfft, int p, int lx, char kind);
int conv(float *c ,float *x, float *h, int L);
int cconv (float *c, float *x, float *y, int L);



//Simple
void MultMV(float *vo, float *m, float *v, int lv);
void MeanM(float *mean, float *M, int nf, int nc);
void VarM(float *var, float *mean, float *M, int nf, int nc);
void Zeros(float *x, int lx);
void Ones(float *x, int lx);
float SumV(float *v, int lv);
void Sum2V(float *v, float *a, float *b, int lv);
void Sub2V(float *v, float *a, float *b, int lv);
float SqSumV(float *x, int l);

void CopyV(float *vo, float *vi, int lv);
float Dot(float *va, float *vb, int lv);
float MaxV(float *x, int lx);
void FabsV(float *vo, float *vi, int l);

int CenterVlo(float *v, int lo, int li);
void MeanNormalMatrix (float *M, int nf, int nc);
void VarMeanNormalMatrix (float *M, int nf, int nc);
void SmoothM (float *M, int nf, int nc, int L, char kind);
void SmoothV(float *vo, float *vi, int nf, int L, char kind);

//Phrase Information
void NormalPI (char *I, int nf, int nc);
void SmoothPI (char *I, int nf, int nc, int L, char kind);


int float2int(float f);
float roundf(float f);


//Win
void WinDDRWide(float *w, int a);
void WinDDRMov(float *w, int wc, int sh, int wd);
void Hamming (float *win, int len);
void SqWin(float *w, int tamw);
void TriangWin (float *w, int l);
void AsymTriangWin(float *w, int Ll, int Lr);


//Filter
void Rxr(int nf);
void RandV(int *va, int tv, int amax);


//Signal
void PSDLPC(float *Sp, float *rx, int lrx, int p, int NSp);

//Missing Date	
void GetMask (int nf);
void Recognizer (int nf);

