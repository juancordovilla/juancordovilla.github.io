#include <stdio.h>
#include <sys/time.h> //for timeval
#include <stdlib.h>
#include <unistd.h>  // usleep()

//////////////////////////////////////////////// SubFun /////////////////////////////////////////////



//////////////////////////////////////////////// Fun /////////////////////////////////////////////
//Printf (sdout) a Matrix
void PrintfM(float *M, int nr, int nc)
{
  int i, j;
  for(j=0; j<nc; j++)
  {
    for(i=0; i<nr; i++)      
      printf("%2.2f ",M[i+j*nr]); 
    printf("\n");  
  }  
}