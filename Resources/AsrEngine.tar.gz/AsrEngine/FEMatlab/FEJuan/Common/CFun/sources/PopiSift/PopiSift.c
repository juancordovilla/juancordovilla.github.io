//Popi plane Siftinting autocorrelation.c

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "../Common/Math/Math.h" 
#include "../Common/IO/IO.h" 



//Read Structurure File
void ReStrF(char *fn)
{
  
  char l[128];
  
  pch = strpbrk (str, key);
  
  while (pch != NULL)
  {
    printf ("%c " , *pch);
    pch = strpbrk (pch+1,key);
  }
  
  
  FILE *fp = fopen (fn, "r" );
  
  
  while ( fgets (l, sizeof(l), fp) != NULL ) 
  {
    l2=strpbrk(l, "=");
    
    
    
    
    fputs ( l, stdout ); /* write the line */
  }
  
  fclose ( fp );
 
  
}




// Main function
void main(int argc, char *argv[]) 
{

	/*int nr, nc;
	float *M;	
	M = ReHtkF(&nr,&nc,argv[1]);
	PrintfM(M, nr, nc);	getchar();*/
	
	
	ReStrF(argv[1]);
	
	
	

}			












