function [Sr,Sur,Su]= splitCovariance( S, m )
%Indexes of the reliable and unreliable features
Sr= S(m,m);
Su= S(~m,~m);
Sur= S(~m,m);