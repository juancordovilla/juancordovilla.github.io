function x_est= softMapImputation( y, w, gmm, k )
u= gmm.centres(k,:)';

%The MAP estimate is the unconditional mean of the unreliable components
x_est= w.*y + (1-w).*u;
%x_est= u; %Ning's proposal
x_est= min([x_est y], [], 2); %Bounded imputation: 0<= xu(i) <= y(i)
