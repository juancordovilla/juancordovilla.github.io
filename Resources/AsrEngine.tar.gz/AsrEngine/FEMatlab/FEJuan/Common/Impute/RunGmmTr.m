function a=RunGmmTr(P)
%

RecTrList='/clusterFS/home/user/jamc/AsrEngine/RECOGNIZER/RECSTAGES/TRAINGen/TrainDir/DAGA/Lists/TrListAll_AAll.txt';
TrDir='/clusterFS/home/user/jamc/RESULTS/FEBase0-3xx/FEAT/TrainReverb';
fi=fopen(RecTrList,'r'); List=textscan(fi,'%s'); List=List{:}; fclose(fi);
GmmTrCList=strcat(TrDir,'/', List,P.ImpExt);




delete(P.ImpGmmF);
GmmTrain(P.ImpGmmF,GmmTrCList,P.ImpNGaus,'diag');
a=-1;
