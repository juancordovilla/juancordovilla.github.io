function Eb=MinSt(Etg,hs,hmi)
%Minimun Statistic (1D for the moment)
Etgs=Smooth(Etg,hs); Eb=MinFilter(Etgs,hmi); 

