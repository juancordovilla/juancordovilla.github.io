function [m,v]=MeanF(x,hw)
%Mean Filter, 
%Outputs: mean and variance
ns=length(x);
m=x; v=x;
for i=1+hw:ns-hw; a=x(i-hw:i+hw); m(i)=mean(a); v(i)=var(a); end
a=x(1:hw); m(1:hw)=mean(a); v(1:hw)=var(a); 
a=x(ns-hw+1:ns); m(ns-hw+1:ns)=mean(a); v(ns-hw+1:ns)=var(a);
