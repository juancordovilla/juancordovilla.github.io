function Msm=SmoothTime(M,hl)
%Smooth Matrix in time
%hl: is half window length
[nr nc]=size(M);
Msm=M;
for i=hl+1:nc-hl; Msm(:,i)=mean(M(:,i-hl:i+hl),2); end