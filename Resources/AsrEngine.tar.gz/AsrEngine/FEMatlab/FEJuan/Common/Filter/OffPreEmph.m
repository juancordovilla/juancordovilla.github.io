function xpe=OffPreEmph(x)
%Remove offset and enhance high freq.)
%Filter coef don't depent on FSam because HTK do it

%xof(i) = x(i)- x(i-1) + 0.999*xof(i-1);
xof=filter([1 -1],[1 -0.999],x);

%xpe(i) = xof(i) - 0.97*xof(i-1);
xpe=filter([1 -0.97],1,xof);


% freqz([1 -0.97],1); pause
