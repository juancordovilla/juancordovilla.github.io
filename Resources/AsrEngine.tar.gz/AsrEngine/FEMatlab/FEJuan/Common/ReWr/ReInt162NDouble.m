function x=ReInt162NDouble(fn)
%Read Int16 file and convert to +-1 Normalized double
[fid] = fopen(fn, 'r', 'b');
x=fread(fid, 'int16');
fclose(fid);
x=double(x)/(2^15);
