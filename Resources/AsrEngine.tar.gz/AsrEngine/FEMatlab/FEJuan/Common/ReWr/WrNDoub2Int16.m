function fn=WrNDoub2Int16(x, do, bn, ext)
%Normalized Double to Int16 and write in a file 
x = x*(2^15);
fn=[do '/' bn ext];
[fid] = fopen(fn, 'w');
fwrite(fid, x, 'int16');
fclose(fid);
