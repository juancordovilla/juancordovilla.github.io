function WrStr(P,fn)
%Write Structure in a file
fi=fopen(fn,'w');
FN=fieldnames(P);
l=length(FN); 
for i=1:l  
    v=P.(FN{i});    
    if(isnumeric(v)); v=num2str(v); end 
    if(isstruct(v)); v='struct'; end
    fprintf(fi,'%s = %s\n',FN{i}, v);
end
fclose(fi);
