function WriteHTKF(fn,M,p)
%Write HTK Function
%Important be carefull with shape of M (only 1 column then only 1 frame)
%sampKind =   9 (User), 8262 (MFCC_0_E), 2886 (MFCC_E_D_A_Z) 


fid=fopen(fn,'w');
[nch nf]=size(M);

%To load one-dim vector in a correct way
if nf==1;   M=reshape(M,nf,nch);   [nch nf]=size(M); end
    

nSamples=nf;
sampSize=4*nch; 
sampPeriod= 100000;
sampKind=   9;

% fwrite(fid, nSamples,  'long');
% fwrite(fid, sampPeriod, 'long');
% fwrite(fid, sampSize, 'short');
% fwrite(fid, sampKind, 'short');

fwrite(fid, nSamples,  'int32');
fwrite(fid, sampPeriod, 'int32');
fwrite(fid, sampSize, 'int16');
fwrite(fid, sampKind, 'int16');
fwrite(fid, M, 'float');


fclose(fid);
if(p==1); disp(['Writted ' fn]); end
