function [ima, imi]=Extrema(x,sp)
%Extrema of vector
%ima: boolean (0 or 1) if a local min/max is detected
%sp==1: Consider sit points such as [ 0 0 4 4 4 0 0] 



ns=length(x);
d=x(2:ns)-x(1:ns-1);
s=sign(d); s=[0;s]; sf=s(2:ns); sb=s(1:ns-1);
ima=(sf==-1&sb==1); imi=(sf==1&sb==-1); 
if sp==1
    ima=ima|(sf==-1&sb==0); imi=imi|(sf==1&sb==0);
end
ima=[ima;0]; imi=[imi;0];

%plot(x), hold on, plot(imi,'g'),  plot(ima,'r'), hold off, pause


