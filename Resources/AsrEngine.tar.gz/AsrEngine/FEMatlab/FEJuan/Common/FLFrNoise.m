function Nest=FLFrNoise(Y,L)
%First Last Frames Noise
%Y: Noisy Magnitude. L: Last/First num of frames (10) 
[FL, nf]=size(Y);
NmL=mean(Y(:,1:L),2);
NmR=mean(Y(:,nf-L:nf),2);
%Nest=repmat((NmL+NmR)/2,[1 nf]);
Nest=Y; %The extremes will be Y
hnf=floor(nf/2); Nest(:,L+1:hnf)=repmat(NmL,[1 hnf-L]); Nest(:,hnf+1:nf-L)=repmat(NmR,[1 nf-hnf-L]);

 







