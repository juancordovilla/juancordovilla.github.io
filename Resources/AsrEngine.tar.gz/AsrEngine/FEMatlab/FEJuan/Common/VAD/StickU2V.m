function v=StickU2V(vo)
%Stick Unvoices To Voices
nf=length(vo);
%initial and final positions (pi,pf) of isolated 1-pulses
v=vo; v(1)=0; v(nf)=0;
j=1; s=0; 
for i=2:nf-1    
    if(s==0 && v(i)==1 && v(i-1)==0); pi(j)=i; s=1; end
    if(s==1 && v(i)==1 && v(i+1)==0); pf(j)=i; j=j+1; s=0; end 
    if(s==1 && v(i)==3 && v(i-1)==1); s=0; end
end
j=j-1; 
%distances to closest 3
di=ones(1,j); df=ones(1,j);
for i=1:j
    ind=find(v(1:pi(i))==3,1,'last'); 
    if (~isempty(ind)); di(i)=pi(i)-ind;
    else di(i)=nf; end        
    ind=find(v(pf(i):nf)==3,1,'first'); 
    if (~isempty(ind)); df(i)=ind-1;
    else df(i)=nf; end    
end
%Fill with 1
for i=1:j
    if(di(i)<df(i));    v(pi(i)-di(i)+1:pi(i))=1;
    else  v(pf(i):pf(i)+df(i)-1)=1; end        
end
v(1)=vo(1); v(nf)=vo(nf);
