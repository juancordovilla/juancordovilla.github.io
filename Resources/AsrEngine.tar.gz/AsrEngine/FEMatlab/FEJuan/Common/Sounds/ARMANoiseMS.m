function n=ARMANoiseMS(f,M,N,p)
%GIVE A VECTOR OF ARMA NOISE depending on Magnitude Shape
%f: Corresponding frequencies [0 1 (is Nyquist)]  
%M: Magnitude shape
%N: N samples
%p: order should be 2*length(M)+2;

b=fir2(p,f,M); a=1;   


%
nw = randn(1,50000+N-1); 
n = filter(b,a,nw);
n = n(50000:end);

n=n/max(n);



        
        







