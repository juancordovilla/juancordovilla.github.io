function m=YNSoftMask(Y,N,Th,Sl,Fl)
%Y,N: should be in Magnitud Spectrum domain units
%Th: (-3db)
%Fl: 0.0608 (exp(-2.80))
Xest=Y-N; i=Xest<Fl; Xest(i)=Fl; 
SNR=20*log10(Xest./N);
%m=SNR>Th; 
m=1./(1+exp(-Sl*(SNR-Th)));
