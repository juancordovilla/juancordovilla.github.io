function Fby=MelMap(y,FL,FS,NCH,N2pi,MF,win)
%
P.win=win; [My nf]=Segmx(y,FL,FS); Y=Msd(My,'x',N2pi,P); Fby=SmoothFreqCompr(Y,NCH,N2pi,MF);