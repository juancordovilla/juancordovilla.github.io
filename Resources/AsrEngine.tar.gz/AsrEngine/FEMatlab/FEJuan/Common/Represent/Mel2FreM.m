function Y=Mel2FreM(Fby,NFT)
%From Mel to Frequency Matrix
%Y follows Msd2 length (NFT even or not)
%Mel' can be considered inverse of Mel matrix

[NCH nf]=size(Fby);

%

[Mel, cb]=MelFB(64,8000,NFT,NCH);



s=sum(Mel); ws=repmat(s',[1 nf]); 
Y=(Mel'*Fby)./ws;

[SL nf]=size(Y);

%
f=1:cb(2)+1; Y(f,:)=repmat(Fby(1,:),[length(f) 1]);
f=cb(NCH+1)+1:SL; Y(f,:)=repmat(Fby(NCH,:),[length(f) 1]);


