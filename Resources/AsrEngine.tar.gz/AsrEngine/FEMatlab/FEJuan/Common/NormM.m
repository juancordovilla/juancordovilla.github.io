function B=NormM(A)
%Normalize [0,1] Matrix A
ma=max(A(:)); mi=min(A(:));
B=(A-mi)/(ma-mi);
