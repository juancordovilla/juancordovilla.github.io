function ym=SynthMaskSig(CG,m,FS)
%Synthesized Masked Signal
%CG (common CochleaGram [26 300*80]), m (mask,[26 300]), FS (Frame Length, 80)


[nch nf]=size(m);
mr=repmat(m,[FS,1]); mr=reshape(mr,[nch nf*FS]);
ms=zeros(size(CG)); ms(:,1:nf*FS)=mr;
CGm=ms.*CG;
ym=sum(CGm);
