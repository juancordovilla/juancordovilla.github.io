function b=MMax(a,l)
%Main (each column) l Maxs
%ls=3; h=ones(ls)/ls; a=imfilter(a,h);
[FL nf]=size(a);
MMa=zeros(FL,nf);
for i=1:nf
    [MMa(:,i), imi]=Extrema(a(:,i),1);
end
am=a; am(not(MMa))=0;

[v,pi]=sort(am,'descend');  
pi=pi(1:l,:); pj=repmat(1:nf,[l 1]);
li=sub2ind([FL nf], pi, pj); b=zeros(FL,nf); b(li)=am(li);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% mhr=MMa;
% se=strel('rectangle',[2 2]); mhm=imclose(mhr,se);
% %mhm=medfilt2(mhr,[]); mh=mhm|mhr; mh=bwareaopen(mh,4);
% subplot(211), imagesc(mhr), axis xy
% subplot(212), imagesc(mhm), axis xy
% pause