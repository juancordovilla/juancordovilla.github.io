function [YDir,XDir]=DBaseYXDir(SDBase,DBSize)
%Give Y (noisy) and X (clean) directories of a DataBase
%YDir: Noisy Dir
%XDir: Clean Dir

k=[SDBase '_' DBSize];


if (strcmp(k,'A2_25'))
    YDir={'testa/N2_SNR0'}; 
    XDir={'testa/clean2'}; 

elseif (strcmp(k,'CHIME_25'))
   YDir={'DevIsol/0dB'}; XDir={'DevIsol/CleanReverb'};
   
elseif (strcmp(k,'EMBEDBAS_25'))
   YDir={'TestEmbed1/0dB'};  XDir={'TestEmbed1/0dBCleanReverb'};   

 
   
 elseif (strcmp(k,'EMBEDBAS_All'))
   YDir={'Train1Reverb/alzn'};   XDir=YDir;     
   %YDir={'TestEmbed1/0dB'};  XDir={'TestEmbed1/0dBCleanReverb'};     
   %YDir={'TestEmbed1/10dBCleanReverb'};  XDir={'TestEmbed1/10dBCleanReverb'};  
  
   
   

elseif (strcmp(k,'BAS_25'))
    %YDir={'TrainClean/G1', 'TrainClean/G2'}; 
    YDir={'TrainReverb/G1', 'TrainReverb/G2'}; 
    %YDir={'TestReverb/T5'};    
    XDir=YDir;
     
    
    
    
elseif (strcmp(k,'BAS_All'))
%     %YDir={'Train1Clean/alzn', 'Train1Clean/behn', 'Train1Clean/chsn', 'Train1Clean/fern', 'Train1Clean/hdbd', 'Train1Clean/jned', 'Train1Clean/kprd', 'Train1Clean/m03a', 'Train1Clean/m11b', 'Train1Clean/m20b', 'Train1Clean/m27a', 'Train1Clean/m42b', 'Train1Clean/m69a', 'Train1Clean/maid', 'Train1Clean/mown', 'Train1Clean/reid', 'Train1Clean/segd', 'Train1Clean/swgd', 'Train1Clean/urln', 'Train1Clean/w06b', 'Train1Clean/w15b', 'Train1Clean/w25b', 'Train1Clean/w35b', 'Train1Clean/w49b', 'Train1Clean/w78a', 'Train1Clean/zimd', 'Train1Clean/anfn', 'Train1Clean/bemn', 'Train1Clean/chvn', 'Train1Clean/gawn', 'Train1Clean/heid', 'Train1Clean/jofn', 'Train1Clean/ktnd', 'Train1Clean/m05a', 'Train1Clean/m12b', 'Train1Clean/m21a', 'Train1Clean/m28b', 'Train1Clean/m44b', 'Train1Clean/m71a', 'Train1Clean/mamn', 'Train1Clean/mshd', 'Train1Clean/rhed', 'Train1Clean/sfrd', 'Train1Clean/swtd', 'Train1Clean/w01b', 'Train1Clean/w07b', 'Train1Clean/w16a', 'Train1Clean/w26a', 'Train1Clean/w37b', 'Train1Clean/w64a', 'Train1Clean/w80a', 'Train1Clean/angn', 'Train1Clean/bied', 'Train1Clean/cofn', 'Train1Clean/getn', 'Train1Clean/hord', 'Train1Clean/kabn', 'Train1Clean/kued', 'Train1Clean/m07a', 'Train1Clean/m13a', 'Train1Clean/m21b', 'Train1Clean/m29a', 'Train1Clean/m46b', 'Train1Clean/m73a', 'Train1Clean/mapn', 'Train1Clean/mxbd', 'Train1Clean/rorn', 'Train1Clean/sirn', 'Train1Clean/sysn', 'Train1Clean/w02a', 'Train1Clean/w08a', 'Train1Clean/w16b', 'Train1Clean/w27b', 'Train1Clean/w39b', 'Train1Clean/w66a', 'Train1Clean/wagd', 'Train1Clean/anmn', 'Train1Clean/bisn', 'Train1Clean/diln', 'Train1Clean/gewn', 'Train1Clean/hsbd', 'Train1Clean/kazn', 'Train1Clean/kufd', 'Train1Clean/m08b', 'Train1Clean/m15a', 'Train1Clean/m22b', 'Train1Clean/m30b', 'Train1Clean/m48b', 'Train1Clean/m75a', 'Train1Clean/mard', 'Train1Clean/obld', 'Train1Clean/rotd', 'Train1Clean/smdd', 'Train1Clean/thpn', 'Train1Clean/w03b', 'Train1Clean/w10a', 'Train1Clean/w17b', 'Train1Clean/w28a', 'Train1Clean/w40b', 'Train1Clean/w68a', 'Train1Clean/wasn', 'Train1Clean/anon', 'Train1Clean/bpmd', 'Train1Clean/disn', 'Train1Clean/gipn', 'Train1Clean/hudd', 'Train1Clean/kimn', 'Train1Clean/ledd', 'Train1Clean/m09a', 'Train1Clean/m17a', 'Train1Clean/m23a', 'Train1Clean/m32b', 'Train1Clean/m50b', 'Train1Clean/m77a', 'Train1Clean/mawn', 'Train1Clean/pasd', 'Train1Clean/rtda', 'Train1Clean/smhd', 'Train1Clean/thsn', 'Train1Clean/w04a', 'Train1Clean/w12a', 'Train1Clean/w20a', 'Train1Clean/w29b', 'Train1Clean/w41b', 'Train1Clean/w70a', 'Train1Clean/wegn', 'Train1Clean/anpn', 'Train1Clean/brfn', 'Train1Clean/eggd', 'Train1Clean/gisn', 'Train1Clean/jaed', 'Train1Clean/kiwn', 'Train1Clean/lind', 'Train1Clean/m09b', 'Train1Clean/m18b', 'Train1Clean/m24b', 'Train1Clean/m34b', 'Train1Clean/m63a', 'Train1Clean/m79a', 'Train1Clean/mihn', 'Train1Clean/paud', 'Train1Clean/sabn', 'Train1Clean/spid', 'Train1Clean/thud', 'Train1Clean/w04b', 'Train1Clean/w13b', 'Train1Clean/w22a', 'Train1Clean/w30a', 'Train1Clean/w43b', 'Train1Clean/w72a', 'Train1Clean/weid', 'Train1Clean/ansn', 'Train1Clean/burd', 'Train1Clean/erld', 'Train1Clean/gued', 'Train1Clean/jand', 'Train1Clean/kkoa', 'Train1Clean/m01a', 'Train1Clean/m10b', 'Train1Clean/m19a', 'Train1Clean/m25a', 'Train1Clean/m36b', 'Train1Clean/m65a', 'Train1Clean/macn', 'Train1Clean/mimn', 'Train1Clean/pegn', 'Train1Clean/scdd', 'Train1Clean/stnd', 'Train1Clean/tlmd', 'Train1Clean/w05b', 'Train1Clean/w14a', 'Train1Clean/w23b', 'Train1Clean/w31b', 'Train1Clean/w45b', 'Train1Clean/w74a', 'Train1Clean/weld', 'Train1Clean/bahn', 'Train1Clean/chrn', 'Train1Clean/esnd', 'Train1Clean/gvnn', 'Train1Clean/jehd', 'Train1Clean/klsn', 'Train1Clean/m02b', 'Train1Clean/m11a', 'Train1Clean/m19b', 'Train1Clean/m26b', 'Train1Clean/m38b', 'Train1Clean/m67a', 'Train1Clean/maed', 'Train1Clean/mobn', 'Train1Clean/ptzd', 'Train1Clean/schd', 'Train1Clean/stpn', 'Train1Clean/topn', 'Train1Clean/w06a', 'Train1Clean/w14b', 'Train1Clean/w24a', 'Train1Clean/w33b', 'Train1Clean/w47b', 'Train1Clean/w76a', 'Train1Clean/wind'};
%     YDir={'Train1Reverb/ktnd'};   
%     % YDir={'Train1Reverb/alzn', 'Train1Reverb/behn', 'Train1Reverb/chsn', 'Train1Reverb/fern', 'Train1Reverb/hdbd', 'Train1Reverb/jned', 'Train1Reverb/kprd', 'Train1Reverb/m03a', 'Train1Reverb/m11b', 'Train1Reverb/m20b', 'Train1Reverb/m27a', 'Train1Reverb/m42b', 'Train1Reverb/m69a', 'Train1Reverb/maid', 'Train1Reverb/mown', 'Train1Reverb/reid', 'Train1Reverb/segd', 'Train1Reverb/swgd', 'Train1Reverb/urln', 'Train1Reverb/w06b', 'Train1Reverb/w15b', 'Train1Reverb/w25b', 'Train1Reverb/w35b', 'Train1Reverb/w49b', 'Train1Reverb/w78a', 'Train1Reverb/zimd', 'Train1Reverb/anfn', 'Train1Reverb/bemn', 'Train1Reverb/chvn', 'Train1Reverb/gawn', 'Train1Reverb/heid', 'Train1Reverb/jofn', 'Train1Reverb/ktnd', 'Train1Reverb/m05a', 'Train1Reverb/m12b', 'Train1Reverb/m21a', 'Train1Reverb/m28b', 'Train1Reverb/m44b', 'Train1Reverb/m71a', 'Train1Reverb/mamn', 'Train1Reverb/mshd', 'Train1Reverb/rhed', 'Train1Reverb/sfrd', 'Train1Reverb/swtd', 'Train1Reverb/w01b', 'Train1Reverb/w07b', 'Train1Reverb/w16a', 'Train1Reverb/w26a', '
%  Train1Reverb/w37b', 'Train1Reverb/w64a', 'Train1Reverb/w80a', 'Train1Reverb/angn', 'Train1Reverb/bied', 'Train1Reverb/cofn', 'Train1Reverb/getn', 'Train1Reverb/hord', 'Train1Reverb/kabn', 'Train1Reverb/kued', 'Train1Reverb/m07a', 'Train1Reverb/m13a', 'Train1Reverb/m21b', 'Train1Reverb/m29a', 'Train1Reverb/m46b', 'Train1Reverb/m73a', 'Train1Reverb/mapn', 'Train1Reverb/mxbd', 'Train1Reverb/rorn', 'Train1Reverb/sirn', 'Train1Reverb/sysn', 'Train1Reverb/w02a', 'Train1Reverb/w08a', 'Train1Reverb/w16b', 'Train1Reverb/w27b', 'Train1Reverb/w39b', 'Train1Reverb/w66a', 'Train1Reverb/wagd', 'Train1Reverb/anmn', 'Train1Reverb/bisn', 'Train1Reverb/diln', 'Train1Reverb/gewn', 'Train1Reverb/hsbd', 'Train1Reverb/kazn', 'Train1Reverb/kufd', 'Train1Reverb/m08b', 'Train1Reverb/m15a', 'Train1Reverb/m22b', 'Train1Reverb/m30b', 'Train1Reverb/m48b', 'Train1Reverb/m75a', 'Train1Reverb/mard', 'Train1Reverb/obld', 'Train1Reverb/rotd', 'Train1Reverb/smdd', 'Train1Reverb/thpn', 'Train1Reverb/w03b', 'Train1Reverb/w10a', 'Train1Reverb/w17b', 'Train1Reverb/w28a', 'Train1Reverb/w40b', 'Train1Reverb/w68a', 'Train1Reverb/wasn', 'Train1Reverb/anon', 'Train1Reverb/bpmd', 'Train1Reverb/disn', 'Train1Reverb/gipn', 'Train1Reverb/hudd', 'Train1Reverb/kimn', 'Train1Reverb/ledd', 'Train1Reverb/m09a', 'Train1Reverb/m17a', 'Train1Reverb/m23a', 'Train1Reverb/m32b', 'Train1Reverb/m50b', 'Train1Reverb/m77a', 'Train1Reverb/mawn', 'Train1Reverb/pasd', 'Train1Reverb/rtda', 'Train1Reverb/smhd', 'Train1Reverb/thsn', 'Train1Reverb/w04a', 'Train1Reverb/w12a', 'Train1Reverb/w20a', 'Train1Reverb/w29b', 'Train1Reverb/w41b', 'Train1Reverb/w70a', 'Train1Reverb/wegn', 'Train1Reverb/anpn', 'Train1Reverb/brfn', 'Train1Reverb/eggd', 'Train1Reverb/gisn', 'Train1Reverb/jaed', 'Train1Reverb/kiwn', 'Train1Reverb/lind', 'Train1Reverb/m09b', 'Train1Reverb/m18b', 'Train1Reverb/m24b', 'Train1Reverb/m34b', 'Train1Reverb/m63a', 'Train1Reverb/m79a', 'Train1Reverb/mihn', 'Train1Reverb/paud', 'Train1Reverb/sabn', 'Train1Reverb/spid', 'Train1Reverb/thud', 'Train1Reverb/w04b', 'Train1Reverb/w13b', 'Train1Reverb/w22a', 'Train1Reverb/w30a', 'Train1Reverb/w43b', 'Train1Reverb/w72a', 'Train1Reverb/weid', 'Train1Reverb/ansn', 'Train1Reverb/burd', 'Train1Reverb/erld', 'Train1Reverb/gued', 'Train1Reverb/jand', 'Train1Reverb/kkoa', 'Train1Reverb/m01a', 'Train1Reverb/m10b', 'Train1Reverb/m19a', 'Train1Reverb/m25a', 'Train1Reverb/m36b', 'Train1Reverb/m65a', 'Train1Reverb/macn', 'Train1Reverb/mimn', 'Train1Reverb/pegn', 'Train1Reverb/scdd', 'Train1Reverb/stnd', 'Train1Reverb/tlmd', 'Train1Reverb/w05b', 'Train1Reverb/w14a', 'Train1Reverb/w23b', 'Train1Reverb/w31b', 'Train1Reverb/w45b', 'Train1Reverb/w74a', 'Train1Reverb/weld', 'Train1Reverb/bahn', 'Train1Reverb/chrn', 'Train1Reverb/esnd', 'Train1Reverb/gvnn', 'Train1Reverb/jehd', 'Train1Reverb/klsn', 'Train1Reverb/m02b', 'Train1Reverb/m11a', 'Train1Reverb/m19b', 'Train1Reverb/m26b', 'Train1Reverb/m38b', 'Train1Reverb/m67a', 'Train1Reverb/maed', 'Train1Reverb/mobn', 'Train1Reverb/ptzd', 'Train1Reverb/schd', 'Train1Reverb/stpn', 'Train1Reverb/topn', 'Train1Reverb/w06a', 'Train1Reverb/w14b', 'Train1Reverb/w24a', 'Train1Reverb/w33b', 'Train1Reverb/w47b', 'Train1Reverb/w76a','Train1Reverb/wind'};
   %  YDir={'Test1Reverb/T1' 'Test1Reverb/T2' 'Test1Reverb/T3' 'Test1Reverb/T4' 'Test1Reverb/T5'};    
   % YDir={'Test1Clean/T1' 'Test1Clean/T2'};    
   XDir=YDir;   
elseif (strcmp(k,'AIRBONE_All'))
   YDir={'TestAwgn/awgnNoisy10dB'};  
   XDir=YDir;  
elseif (strcmp(k,'DIRHA_All'))
   YDir={'TestClean/001M'};  
   XDir=YDir; 
   


 
   
elseif (strcmp(k,'CHIMEWSJ_25'))
   YDir={'DevIsol9dB/050', 'DevIsol0dB/051'}; XDir={'CleanReverb/050', 'CleanReverb/051'}; 
   %YDir={'TrainReverb/011', 'TrainReverb/014', 'TrainReverb/01i', 'TrainReverb/01j', 'TrainReverb/01k', 'TrainReverb/01y', 'TrainReverb/020', 'TrainReverb/205', 'TrainReverb/207', 'TrainReverb/20g', 'TrainReverb/20i', 'TrainReverb/403', 'TrainReverb/405', 'TrainReverb/40e', 'TrainReverb/40g'}; XDir={'TrainReverb/011', 'TrainReverb/014', 'TrainReverb/01i', 'TrainReverb/01j', 'TrainReverb/01k', 'TrainReverb/01y', 'TrainReverb/020', 'TrainReverb/205', 'TrainReverb/207', 'TrainReverb/20g', 'TrainReverb/20i', 'TrainReverb/403', 'TrainReverb/405', 'TrainReverb/40e', 'TrainReverb/40g'};

elseif (strcmp(k,'CHIME_All'))
   %YDir={'DevIsol/9dB'}; XDir={'DevIsol/CleanReverb'};
   %YDir={'DevIsol/CleanReverb'}; XDir={'DevIsol/CleanReverb'}; 
	YDir={'TestIsol/0dB'}; XDir={'TestIsol/CleanReverb'};   
   % YDir={'TrainReverb/id1', 'TrainReverb/id7', 'TrainReverb/id14', 'TrainReverb/id21', 'TrainReverb/id28', 'TrainReverb/id34'}; XDir=YDir;    
   %YDir={'TrainClean/id1', 'TrainClean/id7', 'TrainClean/id14', 'TrainClean/id21', 'TrainClean/id28', 'TrainClean/id34'}; XDir=YDir; 
   %YDir={'TrainNoisy/id1', 'TrainNoisy/id7', 'TrainNoisy/id14', 'TrainNoisy/id21', 'TrainNoisy/id28', 'TrainNoisy/id34'}; XDir=YDir;     
   % YDir={'TrainNoisy/id5'};   XDir=YDir;
   


    
elseif (strcmp(k,'A4_25'))
    YDir={'train_clean/G1', 'train_clean/G2'}; XDir={'train_clean/G1', 'train_clean/G2'}; 
   
else
    disp('ERROR: Unknown Database')
end





