#!/bin/csh


set SoftRoot = /clusterFS/home/user/jamc/SPEECHDATA/Softwares
set MCRROOT = /afs/spsc.tugraz.at/opt/matlab/R2012a 




set path = (${MCRROOT}/bin $path)
mcc -R -singleCompThread -R -nodisplay -R -nojvm -m Fun/FEDir.m \
-I ../../ExtFeat \
-I ../../ExtFeat/FranzFun \
-I ../../ExtFeat/PejmFun \
-I ../../ExtFeat/HannFun \
-I ../../ExtFeat/FranzFun/Fun \
-I ../../ExtFeat/PejmFun/Fun \
-I ../../ExtFeat/HannFun/Fun \
-I ../../ExtFeat/HannFun/bf/weightscvx \
-I ../../ExtFeat/HannFun/bf/weightsds \
-I ../../ExtFeat/HannFun/bf/files \
-I ../../ExtFeat/HannFun/bf/lib \
-I ../../ExtFeat/HannFun/bf/libnew \
-I ../../ExtFeat/HannFun/bf/libold \
-I ../Recognizer \
-I ../Recognizer/Fun \
-I ../FEBase \
-I ../FEVADTunN \
-I ../FESift \
-I ../FEDirha \
-I ../FEOthers \
-I ../FENing \
-I ../FENing/NeedFun \
-I ../FENing/NeedFun/MexFun \
-I ../Common/Impute \
-I ../Common/Impute/Fun \
-I ../Common/CASA \
-I ../Common \
-I ../Common/ReWr \
-I ../Common/Represent \
-I ../Common/Filter \
-I ../Common/Sounds \
-I ../Common/VAD \
-I ../Common/Pitch \
-I ../Common/Pitch/DTWPitch \
-I ../Common/Pitch/DTWPitch/Fun \
-I ../Common/Pitch/StandPitch \
-I $SoftRoot/PitchSoft/yin \
-I $SoftRoot/PitchSoft/voicebox \
-I $SoftRoot/playrec_scripts \



rm -rf  DBParam.m~  MakeFEDir.sh~  mccExcludedFiles.log  readme.txt run_FEDir.sh
mv FEDir Fun/



