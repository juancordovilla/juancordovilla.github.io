function AllRec
%All Recognition


addpath('./Fun'); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Select options manually
% SDBase  = 'EMBEDBAS'; %Speech DataBase: A2, A3, A4, CHIME, CHIMEWSJ, BAS, ...
% DBSize  = 'All'; %Database Size: 25 or All
% FEK     = 'FEDirha'; % FE Kind: FEEtsi, FEVADTunN, ...
% FEOpt   = {'2', '0', '0', '0'}; %FE Options

% Select options depending on paper
[SDBase, DBSize, FEK, FEOpt]=DemoFEPar('2');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Add all paths
[SMRoot, SoftRoot, SpeechRoot, ResRoot, RecRoot]=AddSMPath('../../../..'); 
%[SMRoot, SoftRoot, SpeechRoot, ResRoot, RecRoot]=AddSMPath; 


%Provide audio speech noisy and clean directories 
[YDir,XDir]=DBaseYXDir(SDBase,DBSize); 

%Start Feature Extraction of the noisy dir
l=length(YDir);
for i=1:l 
    FEDir([SpeechRoot '/' SDBase '_' DBSize '/' YDir{i}], [SpeechRoot '/' SDBase '_' DBSize '/' XDir{i}], [ResRoot '/FEProof/' YDir{i}], SMRoot, SoftRoot, SDBase, FEK, FEOpt{1}, FEOpt{2}, FEOpt{3}, FEOpt{4});
end

    
    




