function HIRegions(H,Fb)
%Harmonic Inharmonic regions



n=8;
subplot(411), imagesc(Fb), axis xy
subplot(412), [C,h] = contourf(Fb,n); axis xy
subplot(413), imagesc(H), axis xy
subplot(414), [C,h] = contourf(H,n); axis xy
pause

