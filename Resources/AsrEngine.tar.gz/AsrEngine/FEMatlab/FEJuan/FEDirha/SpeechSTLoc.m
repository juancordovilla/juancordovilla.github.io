function Isol=SpeechSTLoc(y, x, do, bn, P)
%Speech Spatial and Temporal Localization

l=length(P.Info.st);

Isol.y=cell(l,1);
Isol.x=cell(l,1);
Isol.bn=cell(l,1);
Isol.pos=cell(l,1);

for i=1:l
    st=str2double(P.Info.st{i}); en=str2double(P.Info.en{i}); 
    
    Isol.y{i}=y(st:en,:);
    Isol.x{i}=x(st:en,:); 
    Isol.bn{i}=P.Info.bn{i}; 
    Isol.pos{i}=P.Info.pos{i};    

end









