function [a]=FEDirha(y, x, do, bn, P)
%FE for DIRHA (Spatio Temporal Localization, BeamForming and Compensation)


P.BFormK=2;
% P.BFormK=P.FEOpt1;

Isol=SpeechSTLoc(y, x, do, bn, P);
Isol=BFormIsol(Isol,do,P);        
        
a=FEIsol(Isol,do,P);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Isol=BFormIsol(Isol,do,P)
%BeamForming of Isolates
l=length(Isol.y);
Isol.xmonoest=cell(l,1); Isol.xmono=cell(l,1);
for i=1:l
    Isol.xmonoest{i}=BForm(Isol.y{i},Isol.pos{i},do,Isol.bn{i},Isol.x{i},P);
    %Isol.xmono{i}=Isol.x{i}(:,end);
    Isol.xmono{i}=BForm(Isol.x{i},Isol.pos{i},do,Isol.bn{i},Isol.x{i},P);
end

function a=FEIsol(Isol,do,P)
%FE of Isolates
l=length(Isol.xmonoest);
for i=1:l  
    a(i)=FEBFComp(Isol.xmonoest{i},Isol.xmono{i},do,Isol.bn{i},P);
end
a=min(a);

