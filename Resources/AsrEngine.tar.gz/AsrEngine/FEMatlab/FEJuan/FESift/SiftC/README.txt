To compile: $make (the executable FE program will be put in bin)
To execute: /bin/FE Noisy.raw Clean.raw DirOut SiftLength



