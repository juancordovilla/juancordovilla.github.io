 
#include <stdio.h>
#include <stdlib.h> //For exit()
#include <string.h> //For strcpy
#include <math.h>
#include "../Common.h" // for HTK_Data_Frame
#include "../IO/fileio.h" 
#include "../Math/Math.h" 

#define PRE_EMPHASIS           0.97


/////////////////////////////////////////////////// GAMMATONE ///////////////////////////////////////////


/*void PutGammCh(FILE *fp_ch, int nsamples, int ch, int nf, char kind)
{
	FrameInformation FI;
	float x[nsamples];
	int i, j, ini;
		
	//Read the channel in x
	fread(&x[0], sizeof(float), nsamples, fp_ch);
	
	//Gamm frame segmentation in FI
	for(i=0; i<nf; i++)
	{
		Read1FI(&FI, i);
		ini=i*FS;

		if(kind=='x')
		{
			for(j=0; j<FL; j++)		
				FI.Gammfrx[ch][j]=x[j+ini];		
		}
		else
		{
			for(j=0; j<FL; j++)		
				FI.Gammfry[ch][j]=x[j+ini];		
		}		


		Write1FI(FI, i);
	
	}
	//printf("%d  %ld", nsamples/FS, nf);
	//getchar();	
		

}



void GetGammCh (char *rawn, char *bn, char *diro, int nf, char kind)
{
	
	FILE *fp_ch = NULL;
	int ch, nsamples;
	char acgn[STRL], chn[STRL];	
	char rmc[STRL]="rm ", comand[STRL]=" /home/roter/AuroraMFCC/FEnew/bin/bin_aux/Gamm/acg \0";
	
	
	// Execute acg and obtain chn file
	GetFileName(acgn, diro, bn, "acg");
	GetFileName(chn, diro, bn, "ch");
	
	strcat(comand," ");	
	strcat(comand,rawn);
	strcat(comand," ");
	strcat(comand,acgn);	
	strcat(comand," ");	
	strcat(comand,chn);	
	system(comand);	

	// PutGammCh in Frame Information 
	fp_ch = fopen (chn, "rb");
	
	fread(&nsamples, sizeof(int), 1, fp_ch);
	
	for(ch=0; ch<MELCH; ch++)
		PutGammCh(fp_ch, nsamples, ch, nf, kind);
			
	fclose(fp_ch);

	
	
	//rm Files
	strcat(rmc, acgn); 
	strcat(rmc," ");
	strcat(rmc, chn); 
	system(rmc);
	
		
}
*/





//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//N of short samples of a file
int NsFile(FILE *fp)
{
	long L, Pos;
	
	
 	
	Pos = ftell(fp);	
	
	

	fseek(fp, 0L, SEEK_END); 
	L = ftell(fp); 		
	fseek(fp,Pos, SEEK_SET);	
	L=L/sizeof(short);
	return (int)L;
}


//Read All Samples
int ReadAllSamples (float *x, int Swap, FILE *fp)
{
	short s;
	int ns=0;	

	fseek (fp, 0L, SEEK_SET);
	
	
	if (Swap) 
	{
		while (fread (&s, sizeof (short), 1, fp))
			{ s = ((s & 0x00ff) << 8) | ((s & 0xff00) >> 8); x[ns]=(float)s; ns++;}
	}
	else
	{ 
		while (fread (&s, sizeof (short), 1, fp))
			{ x[ns]=(float)s; ns++;}
	}

	return ns;
}


int SegFI(FILE *fp_y, FILE *fp_x, int ns, char *bn, char *diro)
{
	int i, j, nf;
	float x[ns], xof[ns], xpe[ns], y[ns], yof[ns], ype[ns], n[ns];
	FrameInformation FI;

	

	//Read all samples 
	nf=ReadAllSamples(x, 1, fp_x);		
	nf=ReadAllSamples(y, 1, fp_y);
	if (nf!=ns) printf("ERROR: Bad count numb of samples\n");
	Sub2V(n,y,x,ns);
	
		
	//Offset filter
	xof[0]=x[0];
	yof[0]=y[0];
	for(i=1; i<ns; i++)
		{xof[i] = x[i]-x[i-1]+0.999*xof[i-1];
		 yof[i] = y[i]-y[i-1]+0.999*yof[i-1];}
	
	
	//Pre-Enphasis
	xpe[0]= xof[0];
	ype[0]= yof[0];
	for(i=1; i<ns; i++)
		{xpe[i] = xof[i] - PRE_EMPHASIS*xof[i-1];
		 ype[i] = yof[i] - PRE_EMPHASIS*yof[i-1];}
	
	//Segmentation		
	nf=0;
	for(i=0; i<=(ns-FL); i=i+FS)
	{			
		Read1FI(&FI, nf);
		for(j=0; j<FL; j++)
		{			
			FI.y[j]=y[i+j];
			FI.yof[j]=yof[i+j];
			FI.ype[j]=ype[i+j];

			FI.x[j]=x[i+j];
			FI.xof[j]=xof[i+j];
			FI.xpe[j]=xpe[i+j];

			FI.n[j]=FI.y[j]-FI.x[j];
			FI.nof[j]=FI.yof[j]-FI.xof[j];
			FI.npe[j]=FI.ype[j]-FI.xpe[j];		
		}	

		xcorr(FI.rBx, FI.xpe, FI.xpe, FL, 'b'); 
		xcorr(FI.rBy, FI.ype, FI.ype, FL, 'b'); 
		xcorr(FI.rBn, FI.npe, FI.npe, FL, 'b'); 
			
			
		Write1FI(FI, nf);
		nf++;
		
		if ((i+FL-1)>=ns) i=ns;
		
	}

	
	//Store x and y
	WriteCh (y, ns, "y", 0);
	WriteCh (x, ns, "x", 0);	
	WriteCh (n, ns, "n", 0);


	return nf;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


int SegmPrepr(int *nsamp, char *rawy, char *rawx, char *bn, char *diro)
{	
	FILE *fp_y = NULL, *fp_x = NULL;
	int nf;
	
		

	fp_y = fopen (rawy, "rb");
	fp_x = fopen (rawx, "rb");
			
	
	*nsamp=NsFile(fp_y);	

	nf=SegFI(fp_y, fp_x, *nsamp, bn, diro); 	

	fclose(fp_y);
	fclose(fp_x);
	
	
	return nf;
	
}


