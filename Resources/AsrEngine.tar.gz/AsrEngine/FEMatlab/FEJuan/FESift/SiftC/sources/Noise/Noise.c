#include <stdio.h>
#include <stdlib.h> //For exit()
#include <string.h> //For strcpy
#include <math.h>
#include "../Common.h" 
#include "../IO/fileio.h" 
#include "../Math/Math.h" 








/*Make sure that  t0 and t1 is always less than N*/
float PrAv(float *x, int t0, int t1, int T, int Np, int N, int D)
{
	int p0, p1, b0, b1, Nav=0;
	float prav=0.0;
	
	for(p0=0; p0<Np; p0++)
	{
	
		b0=p0*T+t0;
		for(p1=0; p1<Np; p1++)
		{			
			b1=p1*T+t1;
			
			if((abs(b0-b1)>=D)  && b0<N && b1<N)
			{
				prav+=x[b0]*x[b1];
				Nav++;			
			}			
		}
	}

	if(Nav==0)
		return prav=0.0;
	else
		return prav=prav/(float)Nav;
} 


	

int RxS(float *rx, float *x, int T, int Np, int N, int D, char bias, char osa)
{
	int i, j, k, ind[N];
	float a, pr[T][T];
	
	// Basic square table
	for (i=0; i<T; i++)
	{	
		if(i<N)
		{
			for(j=0; j<=i; j++)
			{	
				pr[i][j]=PrAv(x,i,j,T,Np,N,D);
				pr[j][i]=pr[i][j];			
			}
		}
	}
	
	//ind
	for(i=0; i<N; i++) ind[i]=i%T;
	

	//rx basic
	if(osa=='o'){
	if(bias=='b')
	{
		for(k=0; k<N; k++)
		{a=0; for(i=k; i<N; i++) a+=pr[ind[i]][ind[i-k]]; rx[k]=a/(float)(N);}
	}
	else
	{
		for(k=0; k<N; k++)
		{a=0; for(i=k; i<N; i++) a+=pr[ind[i]][ind[i-k]]; rx[k]=a/(float)(N-k);}					
	}}
	else{
	if(bias=='b')
	{
		for(k=0; k<N; k++)
		{a=0; for(i=k; i<N; i++) a+=pr[ind[i]][ind[i-k]]; rx[k+N-1]=a/(float)(N); rx[N-1-k]=rx[k+N-1];}
			
	}
	else
	{
		for(k=0; k<N; k++)
		{a=0; for(i=k; i<N; i++) a+=pr[ind[i]][ind[i-k]]; rx[k+N-1]=a/(float)(N-k); rx[N-1-k]=rx[k+N-1];}
	}}

	
		
		
	return N;
}





/*Rx Sifting*/
int RxSift(float *rxav, float *x, float pf, int Du, int Dv, char bias, char osa)
{
		int lrx, lx=FL, Np, T, D;
			

		D=Dv;
		if(pf<=1.0) {pf=55.0; D=Du;}
 	 					
		T=float2int(pf);
	
		Np=1+FL/T;
		lrx=RxS(rxav, x, T, Np, lx, D, bias, osa);
			
		return lrx;
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Noise(int nf,  char *Dn)
{	
	FrameInformation FI;
	int i,  D=atoi(Dn);
	

		
	//Rosas 
	for(i=0; i<nf; i++)
	{
		
		Read1FI(&FI, i);	
		RxSift(FI.rBxEst, FI.My, FI.pit, D, D, 'b','n'); 					
		Write1FI(FI, i);
	}
     	
	//NoiseEst(nf);
	
		
		
}
	

	
	
	






