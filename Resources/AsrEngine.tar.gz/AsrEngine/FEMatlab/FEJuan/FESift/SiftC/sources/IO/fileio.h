//


void GetBaseName (char *bn, char *cad);
void GetFileName(char *o, char *pn, char *bn, char *ext);


void OpenFileInf();


void DumpPI (float *M, int nf, int nc, char *I);
void WritePI (float *M, int nf, int nc, char *I);

int ReadCh (float *x, int lx, char *I, int ch);
int WriteCh (float *x, int lx, char *I, int ch);


int Read1FI(FrameInformation *FI, int pos);
int Write1FI(FrameInformation FI, int pos);

int Read1FChI(FrameChInformation *FChI, int pos);
int Write1FChI(FrameChInformation FChI, int pos);

void ReadHTKHeader (FILE *fp, int *nf, char *kind, int *lv);






//Print
void PrintVoice (int intensity);
struct timeval restaTiempo(struct timeval *t1, struct timeval *t2);
void TimeStatistic (struct timeval *tini, struct timeval *tfin, long imax);
void PrintfFA (float *arr, int nf, int nc);
void PrintfIA (int *arr, int nf, int nc);
void PrintV(float *v, int tamv);
void Print3V(float *v1, float *v2, float *v3, int tamv);
void PrintfVoice (int intensity);

