/*******************************************************
*	AUTOR: 		Juan Andres Morales Cordovilla 
*			(Granada University). 
*	DESCRIPTION:	Main of FE, Feature Extractor		
**********************************************************/


#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "./Common.h" 
#include "Math/Math.h" 
#include "IO/fileio.h" 




/***************************************
*	     MAIN FUNCTION
***************************************/
int main(int argc, char *argv[]) 
{

	int nf=0, ns;
	char bn[100];
	
	
	
	GetBaseName(bn, argv[1]);
	

	//printf("HOLA: %s\n",n);getchar();
	
	OpenFileInf();

	
	nf=ReadOutFiles(bn, argv[3]);	
	
	
	
	Noise(nf,  argv[4]);	
	
	WriteOutFiles(bn, argv[3], nf, ns);	
	


	Finalize();

	
	
	return 1;

}			












