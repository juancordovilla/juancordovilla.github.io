
#include <stdio.h>
#include <stdlib.h> //For exit()
#include <string.h> //For strcpy
#include "../Common.h" // for HTK_Data_Frame
#include "../IO/fileio.h" 
#include "../Math/Math.h" 



int Obt1VcSm(int nfm);
void Obt2PSm(int nfm);



int ReadAllVcrPr (unsigned char *vcr, float *pr, char *vcfile, char *pfile)
{
	FILE *fp_pit = NULL;
	FILE *fp_vc = NULL;
	int nf=0;
	
	fp_pit = fopen (pfile, "rb");	
	fp_vc = fopen (vcfile, "r"); 		
	
	while(fread(&pr[nf], sizeof(float), 1, fp_pit)&&fscanf(fp_vc,"%c", &vcr[nf]))
		nf++;	
		
	fclose(fp_pit);	
	fclose(fp_vc);
	
	return nf;	

}


int GetPrVcr(unsigned char *vcr, float *pr, char *rawn, char *bn, char *diro)
{
	char xmfcn[STRL], pitn[STRL], vcn[STRL], vad[STRL];
	char fnc[STRL]=" ", rmc[STRL]="rm ";
	int nf;
	
	
	//LAUNCH xFE 
	//Names		
	GetFileName(xmfcn, diro, bn, "xmf");	
	GetFileName(pitn, diro, bn, "pit");	
	GetFileName(vcn, diro, bn, "vc");			
	GetFileName(vad, diro, bn, "vad");

		
	//char comand[STRL]="/home/roter/Tesis10Sheff/ScriptMatlab/MaskEstim/FEFuntions/PitchExtr/JuanPitch/FEChannels/bin/bin_aux/xFE -q -swap -F RAW -fs 8 \0";
	char comand[STRL]="/home/roter/Tesis10/ScriptMatlab/MaskEstim/FEFuntions/PitchExtr/JuanPitch/FEChannels/bin/bin_aux/xFE -q -swap -F RAW -fs 8 \0";
	
	//char comand[STRL]=" /home/roter/Tesis10/Softwares/FENoise/bin/bin_aux/xFE -q -swap -F RAW -fs 8 \0";
	//char comand[STRL]=" /home/roter/AuroraMFCC/FEnew/bin/bin_aux/xaFE -q -swap -F RAW -fs 8 \0";
	strcat(comand,rawn); 
		
			
	
	strcat(fnc,xmfcn);
	strcat(fnc," ");
	strcat(fnc,pitn);
	strcat(fnc," ");
	strcat(fnc,vcn);
	
	strcat(comand,fnc);	
	system(comand);
	
	

	//READ FILES 
	nf=ReadAllVcrPr(vcr, pr, vcn, pitn);
	
	//RM FILES
	//strcat(fnc," ");
	//strcat(fnc,vad);
		
	strcat(rmc, fnc); 
	system(rmc);
	
		

	return nf;
	
}



int xFEPitVc(char *fnoisy, char *fclean, char *bn, char *diro)
{
	FrameInformation FI;
	unsigned char vcr[3000];
	float pr[3000];
	int nf, i;
	
	
		
	//Noisy
	//GetGammCh(fnoisy, bn, diro, nf, 'y'); 
	nf=GetPrVcr(vcr, pr, fnoisy, bn, diro); 
	for(i=0; i<nf; i++)
	{
		Read1FI(&FI, i);		
		FI.vcry=vcr[i];
		FI.pry=pr[i];		
		Write1FI(FI, i);
	}	
	

	//Clean
	//GetGammCh(fclean, bn, diro, nf, 'x'); 
	nf=GetPrVcr(vcr, pr, fclean, bn, diro);	
	for(i=0; i<nf; i++)
	{
		Read1FI(&FI, i);		
		FI.vcrx=vcr[i]; 
		FI.prx=pr[i];		
		Write1FI(FI, i);
	}	
	
	return nf;
	

}



////////////////////////////////////////////////////////////////////////////////////////////////////////


int PitVc(char *fnoisy, char *fclean, char *bn, char *diro, int nf)
{
	int nfxFE;

		
	nfxFE=xFEPitVc(fnoisy, fclean, bn, diro);		
	Obt1VcSm(nf); //3
	Obt2PSm(nf);  //4	

			
	return nfxFE;

}

