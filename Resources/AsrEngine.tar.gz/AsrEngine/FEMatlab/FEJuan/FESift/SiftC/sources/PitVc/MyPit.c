#include <stdio.h>
#include <stdlib.h> //For exit()
#include <string.h> //For strcpy
#include "../Common.h" // for HTK_Data_Frame
#include "../IO/fileio.h" 
#include "../Math/Math.h" 

int Find(float *v, int l, float a)
{
	int i;

	for (i=0; i<l; i++)
	{
		if (v[i]<=a) break;		
	}
	
	return i;
}

int PosMax(float *v, int l)
{
	
	int i, pmax=0;
	float max=v[0];

	for (i=0; i<l; i++)
	{
		if (v[i]>max) {max=v[i]; pmax=i;}
	}	

	return pmax;

}


int PitExtr(float *r, float *x, int l)
{
	int ini, p;
	float  m, rat;

	//R0
	rxosa(r, x, l, 'b'); 	

	//PIT	
	m=SumV(r, l)/l;
	ini=Find(r, l, m);
	p= (ini+PosMax(&r[ini], l-(ini+1)));
	
	rat=r[p]/r[0];
	if (rat<0.7) p=0.0;
			

	return p;

}






////////////////////////////////////////////////
void MyPitExt(int nf)
{	
	FrameInformation FI;
	int i;


	
	//rBxEst
	for(i=0; i<nf; i++)
	{	
		Read1FI(&FI, i);		
		
			
					
	
		Write1FI(FI, i);
		
	}


	//Smooth
		





}

