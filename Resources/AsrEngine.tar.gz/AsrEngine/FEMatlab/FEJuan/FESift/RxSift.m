function [Rxs]=RxSift(My,pit,D,y,x,do,bn,P)
%Rx (Matrix Autocorrelation) Sifting
%Previus compilation (explain).

%Rxs=SiftC(My,pit,D,y,x, do, bn, P);
Rxs=SiftM(My,pit,D);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Rxs=SiftM(My,pit,D)
%Sift Matlab
pit=round(pit);
[FL nf]=size(My);
Rxs=zeros(2*FL-1,nf);
for i=1:nf     
    Rxs(:,i)=SiftMatlab(My(:,i),pit(i),D);  
%     pit=55; x=(sin(2*pi*(0:FL-1)/pit)+sin(2*pi*(0:FL-1)/pit/4)); y=x+randn(1,FL);
%     rxs=SiftMatlab(y',pit,D);   
%     rx=xcorr(x,x,'biased');
%     ry=xcorr(y,y,'biased');    
%     subplot(211), plot(x),
%     subplot(212), plot(rx), hold on, plot(ry,'r'), plot(rxs,'ro'), hold off
%     pause    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Rxs=SiftC(My,pit,D,y,x, do, bn, P)
%Sift C 
%Much faster than the Matlab implementation. 
%Need to be compiled (execute makefile in /SiftC/sources/).
WriteHTKF([do '/' bn '.My'], My, 0);
WriteHTKF([do '/' bn '.pit'], pit, 0);
fny=WrNDoub2Int16(y, do, bn, '.08');
fnx=fny;
%
bin = [P.SMRoot '/FEJuan/FESift/SiftC/bin/Sift']; 
system([bin ' ' fny ' ' fnx ' ' do ' ' num2str(D)]);
Rxs=ReadHTKF([do '/' bn '.rBxEst'],0,0);  
[FL nf]=size(Rxs);
if (FL~=2*P.FL-1);    fprintf('ERROR: In in Common.h, modify  FL, FS, etc.. and compile\n'); end
%
delete(fny,[do '/' bn '.My'],[do '/' bn '.pit'],[do '/' bn '.rBxEst']);






