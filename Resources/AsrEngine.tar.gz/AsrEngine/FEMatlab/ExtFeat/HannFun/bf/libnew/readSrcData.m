function SrcArray = readSrcData(FileNameString, ImpString)

iLine = 1; 

fid = fopen(FileNameString); 
DataLineArray = fgets(fid);

while ischar(DataLineArray)    
    DataLineStruct = textscan(DataLineArray,'%s %s %*s %*s x=%f y=%f z=%f %*s'); 
    DataLineStruct{1}{1} = regexprep(DataLineStruct{1}{1},'"',''); 
    if  (~isempty(strfind(DataLineStruct{1}{1},'Livingroom'))) && (~isempty(strfind(DataLineStruct{2}{1}, ImpString)))
        SrcArray = [DataLineStruct{3}; -DataLineStruct{4}; DataLineStruct{5}]; % Note: Consider -y to map given coordinate system into mathematical correct coordinate system. 
    end    
    
    DataLineArray = fgets(fid);    
    iLine = iLine+1; 
end

end
