function MicArray = readMicData(FileNameString)

iLine = 1; 
iChannel = 1; 

fid  = fopen(FileNameString); 
DataLineArray = fgets(fid);

while ischar(DataLineArray)
    DataLineStruct = textscan(DataLineArray,'%s %*s %*s x=%f; y=%f; z=%f; %*s'); 
    if  (~isempty(strfind(DataLineStruct{1}{1},'LA')))    
        MicArray(:,iChannel) = [DataLineStruct{2}; -DataLineStruct{3}; DataLineStruct{4}]; % Note: Consider -y to map given coordinate system into mathematical correct coordinate system. 
        iChannel = iChannel + 1; 
    end
    
    DataLineArray = fgets(fid);    
    iLine = iLine + 1; 
end

end
