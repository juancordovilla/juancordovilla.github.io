function pyx=RefCleanPit(ys, xs, do, bn, P, opt, SFE, pf, py)
%




x=xs(:,end);
SAx=sum(SFE.Ax); SAx=squeeze(SAx); 
nf=size(SAx,2);
f=14/13; %factor>1

%[pfx,hpf,lpf]=PitCorr(SAx,f,pf);
[pyx,hpy,lpy]=PitCorr(SAx,f,py);


% subplot(311), imagesc(nthroot(SAx,3)), axis xy
% subplot(312), plot(pf), hold on, plot(hpf,'r'), plot(lpf,'r'), plot(pfx,'g'), hold off, xlim([1 nf]) 
% subplot(313), plot(py), hold on, plot(hpy,'r'), plot(lpy,'r'), plot(pyx,'g'), hold off, xlim([1 nf]) 
% pause



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [px,ph,pl]=PitCorr(SAx,f,p)
%Pitch Correction
nf=size(SAx,2);
%PitMi=round(P.FSamp/P.HPitHz(2)); PitMa=round(P.FSamp/P.HPitHz(1)); 
PitMi=1; PitMa=size(SAx,1);
SAx(1:PitMi,:)=0;
ph=min(round(p*f),PitMa);
pl=max(round(p/f),PitMi); pl(p<1)=0;
px=zeros(1,nf); 
for i=1:nf
    if (p(i)>1)        
        [v pos]=max(SAx(pl(i)+1:ph(i)+1,i));       
        px(i)=pl(i)+pos-1;
    end
end
