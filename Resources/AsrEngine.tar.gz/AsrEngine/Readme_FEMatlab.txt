-----------------------------------------------
HOW TO USE FEMatlab 
Description: demo with the Matlab Feature-Extractors (FE) of the main Juan Andres Morales Cordovilla papers. 
-----------------------------------------------
1) Open Matlab and in ./FEMatlab/FEJuan/Recognizer/AllRec.m., select the FE of the paper by editing the number of the function DemoFEPar('2'). 
The correspondence between the numbers and the FEs of the papers can be found inside the DemoFEPar function.

2) Launch AllRec.m in the Matlab command line. The input signal and the most important output products of the FE such as the clean cepstrogram estimation, the noise spectrogram estimation, the pitch, the missing data mask, etc., will be plotted and written in a HTK format in ./RESULTS/FEProof/...


-----------------------------------------------
HOW FEMatlab WORKS
-----------------------------------------------
Imagine you select the FE of the VAD+Tunnelling paper (DemoFEPar('2')), then the most important steps are: 
1) In AllRec.m:
- DemoFEPar: select some FE Parameters such as the FE Kind (FEK=’FEVadTunN’) and the speech database (SDBase=’A2’) of the input audio.  Note that the database selected in this case is Aurora-2 because the paper does the experiments with this database. 
- AddSMPath: add all the needed script matlab paths and select some important roots such as the scriptmatlab (SMRoot) , the output results (ResRoot) and the speech root of the audio inputs (SpeechRoot). Note that all the audios of different databases can be found in ./SPEECHDATADemo.
 - DBaseYXDir: depending on the database, select the noisy and corresponding clean folders of the audios to which their features will be extracted. 
 It is important to point out that the clean folder is only for benchmarks comparisons.
- FEDir: feature extraction of each noisy folder (dy). Other parameters such as the clean folder (dx), output folder (do), scriptmatlab root (SMRoot) and feature options (FEOpt) are passed.

2) In FEDir.m:
- DBParam: put in structure P the parameters which depends on the database such as frame and shift in seconds (FLSec and FSSec) and number of channels of the filterbank (NCH).
-  FED: read each audio file of the noisy folder with ReNormYX, obtain its basename (bn) and extract their features using the corresponding FE. In our case we use the FEVADTunN.

3) In FEVADTunN:
- At the beginning: we set many parameters such as the hamming window (P.win) for the spectrogram estimation, the minimum pitch value (P.MiPitHz) or the SNR threshold of the missing data mask (P.Thr).
- SegmRepr: Segment the signal (Segmx), obtain the magnitude spectrogram density (Msd), and the mel-spectrogram or filterbank representation (SmoothFreqCompr).
- PitVad: Obtain the pitch and the voice activity detection. The default pitch extraction (AcPitch) is based on the autocorrelation and is sufficiently simple to be executed in any platform without any extra mex or gcc compilation. Other pitch extractors such as DTWPitch, xFEPitch or YinPitch need to compile some of their subfuction. By default these subfuction are compiled for a Linux-64 bits platform.

- NoiseMask: is the core function of the paper and estimates the Vad+Tun noise by means of vad and a tunnelling noise estimation which employs the pitch. (If you explore more deeply you will see that TunN and NIntLin are the functions for tunnelling estimation). Also NoiseMask estimates the soft missing data. 

- WriteOutFiles: DemoPlotRes function plots the most important input-output (noisy signal, noisy mel-spectrogram, noise and mask estimation and pitch), AppDeltas adds the deltas and delta-deltas and finally WriteHTKF writes in HTK format, in the output dir (do), the needed features for recognition. 


Please, contact me (jamc@ugr.es) for any extra trouble.



