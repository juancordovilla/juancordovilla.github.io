Title: Code for IoT controlled automatically by Web Scrapping
Author: Juan A. Morales-Cordovilla
License: CC-GNU
Keywords: (Arduino, Node.js, Real Time,...)
Use: 
- Mount Arduino system and pass the code as explained here: https://juancordovilla.github.io/research/Resources.html
- Open a terminal in a Node.js server and launch  "node app.js"
- Open a web-browser in a client as "localhost:3000" or "IPServer:3000" and control the system manually
- Open a terminal in the server and launch "node scrap.js" if you prefer automatically control.
Contact: Juan A. Morales-Cordovilla (see my web)
