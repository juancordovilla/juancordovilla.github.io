//Libraries
const puppeteer = require('puppeteer');

//Functions
async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function sendCheckbox(page,cId){
    console.log('Sending ' + cId);
    await page.click('#' + cId);                       
}


async function setSlider(page,slId, value) {
        console.log('Sending ' + slId + ' ' + value);
        // Set the value of the slider
        await page.evaluate(function(page,value,slId) {
        const slider = document.getElementById(slId);
        slider.value = value;
        slider.dispatchEvent(new Event('input'));
        }, page, value, slId);    
}  

// Function to scrape and log the potValue
//Arrow Function Expresión, notation from functional programming, () => {...} equivalent to function () {...}
const readElem = async (page,elId) => {
    // Get the text content of the element with id "pot"
    const val = await page.$eval('#' + elId, element => element.textContent.trim());
    console.log('Read element:', val);   
}; 


//MAIN
async function mainJuanScrap() {
    
    // Launch a headless browser instance
        const browser = await puppeteer.launch();
        const page = await browser.newPage();
        await page.goto('http://localhost:3000/');
        
      

  while(true){      
        //          
        await sendCheckbox(page,'c1');
        await sleep(2000); 
        await sendCheckbox(page,'c2');
        await sleep(2000);        
   
       //
        await setSlider(page,'slider', 10);
        await sleep(2000);         
        await setSlider(page,'slider', 170);  
        await sleep(2000); 
              
        await readElem(page,'pot');
        await sleep(2000);
       
        // 
        await sendCheckbox(page,'c1');
        await sleep(2000); 
        await sendCheckbox(page,'c2');
        await sleep(2000); 
      
    }  
  
   await browser.close();
    
}

// Call the function to scrape the website and toggle the checkbox
mainJuanScrap();

