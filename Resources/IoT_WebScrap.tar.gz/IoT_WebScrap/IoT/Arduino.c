#include <Servo.h>
//Actuators
const int ledRPin = 13, ledGPin = 12; 
const int pumpPin = 8, servPin=9, servPin2=6;
//Sensors
const int potPin = A0, butPin = 7; 
//
const int EmStrL=8, ReStrL=15;  //Emit/Receive String Length
//
Servo myServo; // Create servo object
Servo myServo2; // Create servo object

int potVal, servPos, servPosAnt,  butState, ledRVal, ledGVal, pumpVal;
char s[EmStrL]; //sensor string to emit ex. Po%03dBu%d
char a[ReStrL];  //a="c10c21s1175c40"; string to receive 

void setup()
{
  pinMode(ledRPin, OUTPUT);  pinMode(ledGPin, OUTPUT); pinMode(pumpPin, OUTPUT);
  pinMode(butPin, INPUT_PULLUP); 
  myServo.attach(servPin);    myServo.write(0); // Calibrate Servo
  myServo2.attach(servPin2);   myServo2.write(0); // Calibrate Servo

  Serial.begin(9600); 
}

void loop()
{
  /*Sensors*/
  potVal=analogRead(potPin); potVal=map(potVal,0,1023,0,255);  //for 5V
  //potVal=map(potVal,0,690,0,255); //for 3.5V
  //Sensor Buttom: we invert  digitalRead(butPin) is 1 (not pressed) or 0 (pressed)
  butState = 1-digitalRead(butPin);  
  sprintf(s, "Po%03dBu%d", potVal, butState);
  Serial.println(s); //Emit sensor string
  
  /*Actuators*/
  if(Serial.available())    { 
    Serial.readBytes(a,ReStrL); //b11b20s1089b40
    ledRVal = a[2]-48; //a[2]-'0'; convert to Int
    ledGVal = a[5]-48; //a[5]-'0'; convert to Int
    pumpVal = a[13]-48; //a[5]-'0'; convert to Int
    //servPos = (a[8]-'0')*100+(a[9]-'0')*10+(a[10]-'0'); 
    //servPos = (a[8]*100+a[9]*10+a[10]*1)-'0'*(100+10+1);    
    servPos = (a[8]*100+a[9]*10+a[10])-5328;

    //if(servPos >= 2 && servPos < 178) {myServo2.write(servPos); myServo.write(servPos); }

     if(servPos != servPosAnt && (servPos >= 5 && servPos < 175)) {servPosAnt=servPos; myServo2.write(servPos); myServo.write(servPos); }

    if(ledRVal==1) { digitalWrite(ledRPin, HIGH);}
    else {digitalWrite(ledRPin, LOW);  }    
    if(ledGVal==1) { digitalWrite(ledGPin, HIGH);}
    else {digitalWrite(ledGPin, LOW);  }

    if(pumpVal==1 && digitalRead(pumpPin)==LOW) {digitalWrite(pumpPin, HIGH); } //avoids HIGH many times
    if(pumpVal==0 && digitalRead(pumpPin)==HIGH) {digitalWrite(pumpPin, LOW);  }

  }
}

