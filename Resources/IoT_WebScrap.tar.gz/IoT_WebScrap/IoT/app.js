//Juan A. 
const { SerialPort } = require('serialport')
const serialport = new SerialPort({path: '/dev/ttyACM0', baudRate: 9600 })
const { ReadlineParser } = require('@serialport/parser-readline');
const express = require('express'); const http = require('http');
const socketIo = require('socket.io');
const app = express(); const server = http.createServer(app);
const io = socketIo(server); const port = 3000;
//only the files from public can be served to a client
app.use(express.static('./publicJuan'));

//WebSocket connection handling
io.on('connection', (socket) => {  //server waiting for the connection client event
  const userIP = socket.handshake.address; //IP del cliente    
  console.log(`A user connected from IP: ${userIP}`); //message when client connected  
  /*Actuators: slider servomotor */
  // Function to execute when a  meassage with Id 'ValuesJuan' is recieved
  socket.on('valuesJuan', (rVal) => { //receive client value   
    io.emit('updatedValuesJuan', rVal); // re-broadcast the updated value to all connected clients  
    console.log(`Sent to serial: ${rVal}`); //console
    serialport.write(`${rVal}\n`); //write value to serial port       
   }); 
  /*Sensors: box potentiometer*/
  // Create a parser to read lines from the serial port
  const parser = serialport.pipe(new ReadlineParser({ delimiter: '\n' }));
  // Listen for incoming serial data and emit it to the connected clients using WebSocket
  parser.on('data', (data) => { //when parser receives a data (until delimiter) execute that:
    io.emit('serialDataJuan', data.trim()); //broadcast message (with id=serialDataJuan) 
    });                                     //to all clients connected to socket
});

// Start the server
server.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});



