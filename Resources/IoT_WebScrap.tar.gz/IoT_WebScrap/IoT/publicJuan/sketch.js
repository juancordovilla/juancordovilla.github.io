//Juan A. Morales
const socket = io();
const serialDataBox = document.getElementById('serialDataBox');
const s1 = document.getElementById('slider');
const upVal = document.getElementById('upVal');   
const c1 = document.getElementById('c1');
const c2 = document.getElementById('c2');
const c3 = document.getElementById('c3');
const c4 = document.getElementById('c4');
const p1 = document.getElementById('pot');
var eVal, s1ValPad;
/*Actuators: Slider and checker*/
function eFun(){    
    //emited Values (+ c1.checked) convert bolean to 0/1    
    s1ValPad=s1.value.toString().padStart(3, "0");    
    eVal = 'b1' + (+ c1.checked) + 'b2' + (+ c2.checked) + 's1' + s1ValPad + 'b4' + (+ c4.checked);    
    socket.emit('valuesJuan', eVal);  //sent value with Id sliderValueJuan     
};
//sent slider value to server
c1.addEventListener('change', eFun);
c2.addEventListener('change', eFun);
c4.addEventListener('change', eFun);
s1.addEventListener('input', eFun);
//replace the actuators values with the one reemited by the server	
socket.on('updatedValuesJuan', (val) => {  //receive server value with id updateSliderJuan    
    s1.value=val.substring(8, 11);
    upVal.textContent = `Cadena valores de actuadores (re-actual): ${val}`;
});

/*Sensors: Box potentiometer and button*/  
socket.on('serialDataJuan', (data) => {
    // Replace the content of the box with the latest data
    serialDataBox.textContent = `Cadena valores de sensores (actual): ${data}`; //Po255Bu1
    p1.textContent = `Humedad (A0): ${data.substring(2,5)}`;
    c3.checked=!!+data.substring(7,8); //convert string '0' or '1' to false or true    
});
    
